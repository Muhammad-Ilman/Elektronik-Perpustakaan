<!-- Elektronik Perpustakaan Content -->
  
<?php
ob_start();
session_start();
    if (!isset($_SESSION['username'])) {
      header('location: LOGIN');
      
    } else {
      
          require_once("CONFIG/koneksi.php");
          require_once("ASSETS/TEMPLATE/header.php");

               if(@$page = $_GET['page']) {
                 if ($page == "buku") {
                         if (@$_GET['hal'] == "create" ||
                             @$_GET['hal'] == "update" ) {
                              include("MODUL/DATA_BUKU/buku_baru.php");
                       }
                     elseif (@$_GET['hal'] == "delete" ) {
                              include("MODUL/DATA_BUKU/data_buku.php");
                       }
                     elseif (@$_GET['hal'] == "detail" ) {
                              include("MODUL/DATA_BUKU/detail.php");
                     } else {
                         include("MODUL/DATA_BUKU/data_buku.php");
                     }
                 }
                 
                 if ($page == "kategori") {
                         if (@$_GET['hal'] == "create" || 
                             @$_GET['hal'] == "update"  ) {
                              include("MODUL/DATA_KATEGORI/kategori_baru.php");
                         }
                     elseif (@$_GET['hal'] == "delete" ) {
                              include("MODUL/DATA_KATEGORI/data_kategori.php");
                         } else {
                              include("MODUL/DATA_KATEGORI/data_kategori.php");
                         }
                }
                
                 if ($page == "lokasi") {
                         if (@$_GET['hal'] == "create" || 
                             @$_GET['hal'] == "update"  ) {
                              include("MODUL/DATA_LOKASI/lokasi_baru.php");
                         }
                     elseif (@$_GET['hal'] == "delete" ) {
                              include("MODUL/DATA_LOKASI/data_lokasi.php");
                         } else {
                              include("MODUL/DATA_LOKASI/data_lokasi.php");
                         }
                }
                
                 if ($page == "sumber") {
                         if (@$_GET['hal'] == "create" || 
                             @$_GET['hal'] == "update"  ) {
                              include("MODUL/DATA_SUMBER/sumber_baru.php");
                         }
                     elseif (@$_GET['hal'] == "delete" ) {
                              include("MODUL/DATA_SUMBER/data_sumber.php");
                         } else {
                              include("MODUL/DATA_SUMBER/data_sumber.php");
                         }
                }
                
                 if ($page == "users") {
                         if (@$_GET['hal'] == "create" || 
                             @$_GET['hal'] == "update"  ) {
                              include("MODUL/DATA_USERS/users_baru.php");
                         }
                     elseif (@$_GET['hal'] == "delete" ) {
                              include("MODUL/DATA_USERS/data_users.php");
                         } else {
                              include("MODUL/DATA_USERS/data_users.php");
                         }
                }

                 
                 
                 
                 
             elseif ($page == "lainnya") {
                         if (@$_GET['hal'] == "disclaimer" ) {
                              include("MODUL/LAINNYA/disclaimer.php");
                         }
                     elseif (@$_GET['hal']) {
                         // code...
                       }
             }
           
             elseif ($page == "error") {
                   include("MODUL/ERROR/403.html");
             }  
               
               
     
 
               }
   
            else {
                 include("MODUL/Dashboard.php");
          }
     
          require_once("ASSETS/TEMPLATE/footer.php");

    }
?>