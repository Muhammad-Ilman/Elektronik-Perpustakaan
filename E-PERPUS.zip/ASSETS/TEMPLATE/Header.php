<?php
date_default_timezone_set('Asia/Jakarta');
?>
<!-- Elektronik Perpustakaan Header -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, Author etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="icon" href="FILE/LOGO_E-PERPUS.png" />

    <title>Elektronik Perpustakaan</title>
    
    

    <!-- Bootstrap 
    <link href="ASSETS/Bootstrap-5/css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="ASSETS/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="ASSETS/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="ASSETS/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
      <!-- NProgress -->
    <link href="ASSETS/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="ASSETS/vendors/animate.css/animate.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="ASSETS/vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>

    <!-- Custom Theme Style -->
    <link href="ASSETS/vendors/build/css/custom.min.css" rel="stylesheet">

  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="" class="site_title"><i class="fa fa-book"></i> <span>E-PERPUS</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="ASSETS/FILE/SMPN3CIBEBER.png" alt="SMPN3CIBEBER" class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome <?=$_SESSION['username']?></span>
                <h2><?=$_SESSION['LEVEL']?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />
            
            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>ADMINISTRATOR PANEL</h3>
                <ul class="nav side-menu">
                
             <!-- Dashboard -->   
                  <li><a href="HOME"><i class="fa fa-dashboard"></i> Dashboard</span></a>
                  </li>
             <!-- Dashboard end -->
             <!-- Data Buku -->
                  <li><a><i class="fa fa-book"></i> Data Buku<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                   <?php if( $_SESSION['LEVEL'] == "ADMINISTRATOR" || $_SESSION['LEVEL'] == "OPERATOR") { ?>
                      <li><a href="?page=buku&hal=create">BUKU BARU</a></li>
                   <? } ?>
                      <li><a href="?page=buku">DATA BUKU</a>
                      </li>
                      <li><a href="?page=kategori">DATA KATEGORI BUKU</a>
                      </li>
                      <li><a href="?page=lokasi">DATA LOKASI RAK BUKU</a>
                      </li>
                      <li><a href="?page=sumber">DATA SUMBER PENGADAAN</a>
                      </li>
                    </ul>
                  </li>
              <!-- Data Buku End -->
              <!-- Data Peminjam -->
                  <li><a><i class="fa fa-group"></i> Data Peminjam <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                <?php if( $_SESSION['LEVEL'] == "ADMINISTRATOR" || $_SESSION['LEVEL'] == "OPERATOR") { ?>
                      <li><a href="?page=users&hal=create">PEMINJAM BARU</a></li>
               <? } ?>
                      <li><a href="?page=users"> DATA PEMINJAM</a></li>
                        <li><a>DATA SISWA KELAS VII<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                      <li><a href="?page=siswa&class=7A"> Data Siswa VII-A</a></li>
                      <li><a href="?page=siswa&class=7B"> Data Siswa VII-B</a></li>
                      <li><a href="?page=siswa&class=7C"> Data Siswa VII-C</a></li>
                      <li><a href="?page=siswa&class=7D"> Data Siswa VII-D</a></li>
                      <li><a href="?page=siswa&class=7E"> Data Siswa VII-E</a></li>
                          </ul>
                        </li>
                        <li><a>DATA SISWA KELAS VIII<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                      <li><a href="?page=siswa&class=8A"> Data Siswa VIII-A</a></li>
                      <li><a href="?page=siswa&class=8B"> Data Siswa VIII-B</a></li>
                      <li><a href="?page=siswa&class=8C"> Data Siswa VIII-C</a></li>
                      <li><a href="?page=siswa&class=8D"> Data Siswa VIII-D</a></li>
                      <li><a href="?page=siswa&class=8E"> Data Siswa VIII-E</a></li>
                          </ul>
                        </li>
                        <li><a>DATA SISWA KELAS IX<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                      <li><a href="?page=siswa&class=9A"> Data Siswa IX-A</a></li>
                      <li><a href="?page=siswa&class=9B"> Data Siswa IX-B</a></li>
                      <li><a href="?page=siswa&class=9C"> Data Siswa IX-C</a></li>
                      <li><a href="?page=siswa&class=9D"> Data Siswa IX-D</a></li>
                      <li><a href="?page=siswa&class=9E"> Data Siswa IX-E</a></li>
                          </ul>
                        </li>

                    </ul>
                  </li>
              <!-- Data Peminjam End -->
              <?php if( $_SESSION['LEVEL'] == "ADMINISTRATOR" || $_SESSION['LEVEL'] == "OPERATOR") { ?>
              <!-- Data Simpan Pinjam -->
                  <li><a><i class="fa fa-refresh fa-spin fa-1x"></i> Sirkulasi <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="#">Pinjaman Baru</a></li>
                      <li><a href="#">Data Kunjungan</a></li>
                      <li><a href="#">Data Peminjaman<span class="fa fa-sign-out"></span></a></li>
                      <li><a href="#">Data Pengembalian<span class="fa fa-sign-in"></span></a></li>
                    </ul>
                  </li>
              <!-- Data Simpan Pinjam End -->
              <? } ?>
              <?php if($_SESSION['LEVEL'] == "ADMINISTRATOR"){ ?>
              <!-- Data Administrator Master -->
                  <li><a><i class="fa fa-sitemap"></i> Data Admin <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="#">Master Admin</a></li>
                      <li><a href="#">Operator</a></li>
                      <li><a href="#">Editor</a></li>
                    </ul>
                  </li>
              <!-- Data Administrator End -->
              <? } ?>
              <?php if($_SESSION['LEVEL'] == "ADMINISTRATOR" || $_SESSION['LEVEL'] == "OPERATOR"){ ?>
              <!-- Backup Database -->
                  <li><a><i class="fa fa-database"></i>BACKUP <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="#">Database Buku<span class="fa fa-database"></span></a></li>
                      <li><a href="#">Database Peminjam<span class="fa fa-database"></span></a></li>
                      <li><a href="#">Database User<span class="fa fa-database"></span></a></li>
                    </ul>
                  </li>
              <!-- Backup Database End -->
                            <? } ?>
              <!-- Lainnya -->
                </ul>
              </div>
              <div class="menu_section">
                <h3>Lainnya</h3>
                <ul class="nav side-menu">

                  <li><a><i class="fa fa-cogs"></a></i>
                 
                          <ul class="nav child_menu">
                            <li>
                            <a href="#">Tentang E-PERPUS</a>
                            </li>
                            <li><a href="#">Terms and Condition</a>
                            </li>
                            <li><a href="MODUL/LAINNYA/Privacy_policy.php">Privacy Policy</a>
                            </li>
                            </li>
                            <li><a href="?page=lainnya&hal=disclaimer"></span>Disclaimer</a>
                            </li>
                            </li>
                            <li><a href="?page=login">About Depeloper</a>
                            </li>
                          </ul>
                      
                    
                  </li>            
                </ul>
              </div>
            </div>
            <!-- Lainnya End -->
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer small">
              <a data-toggle="tooltip" data-placement="top" title="Github">
                <span class="fa fa-github" aria-hidden="false"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Dropbox">
                <span class="fa fa-dropbox" aria-hidden="false"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Information">
                <span class="fa fa-info-circle" aria-hidden="false"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout">
                <span class="fa fa-power-off" aria-hidden="false"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a data-toggle="tooltip" data-placement="top" title="Collapse Menu" data-placement="right" id="menu_toggle"><i class="fa fa-th"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open animated--grow-in" style="padding-left: 15px;">
                  <a href="javascript:;" style="text-decoration:none" class="user-profile dropdown-toggle " aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="true">
                    <img src="CONTROLLER/ADMIN_SYSTEM/G_ADMIN/<?=$_SESSION['gambar']?>" alt="G_LEVEL">
                    <?=$_SESSION['LEVEL']?>
                  </a>
                
                
                
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                       <a class="dropdown-item"> My Profile 
                         <span class="fa fa-user pull-right"></span>
                         </a>
                      <a class="dropdown-item" href="#">
                        <span>Settings</span>
                        <span class="fa fa-cog pull-right"></span>
                      </a>
                  <a class="dropdown-item" href="#">Help                 
                  <span class="fa fa-question-circle pull-right"></span>
                  </a>
                   <a class="dropdown-item"  href="CONTROLLER/ADMIN_SYSTEM/logout.php"><i class="fa fa-sign-out pull-right"></i> Log Out
                   </a>
                  </div>
                  
                  
                </li>


                 
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->
        
<!-- E - PERPUS Header end -->