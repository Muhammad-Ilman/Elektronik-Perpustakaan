 <!-- Elektronik Perpustakaan footer content -->
        <footer>
          <div class="pull-right">
               <span class="fa fa-book"></span>
             <a href="#" style="text-decoration:none"> E-PERPUS </a><span class="fa fa-copyright"></span> <?=date('yy')?> | SMP NEGERI 3 CIBEBER
          </div>

          <div class="clearfix"></div>
        </footer>
 <!-- end footer content -->
      </div>
    </div>


    <!-- ECharts -->
    <script src="ASSETS/vendors/echarts/dist/echarts.min.js"></script>
    <script src="ASSETS/vendors/echarts/map/js/china.js"></script>
    <!-- FastClick -->
    <script src="ASSETS/vendors/fastclick/lib/fastclick.js"></script>
    <!-- Chart.js -->
    <script src="ASSETS/vendors/Chart.js/dist/Chart.min.js"></script>
    <script src="ASSETS/vendors/moment/min/moment.min.js"></script>
    <!-- jQuery -->
    <script src="ASSETS/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap 5 OFF
    <script src="ASSETS/Bootstrap-5/js/bootstrap.min.js"></script>
    <!-- Bootstrap -->
    <script src="ASSETS/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- NProgress -->
    <script src="ASSETS/vendors/nprogress/nprogress.js"></script>
    <!-- JQVMap -->
    <script src="ASSETS/vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="ASSETS/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="ASSETS/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
	<!-- jQuery Tags Input -->
	<script src="ASSETS/vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
	<!-- validator form -->
	<script src="ASSETS/vendors/validator/validator.js"></script>
	    <!-- bootstrap-progressbar -->
    <script src="ASSETS/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
	    <!-- NProgress -->
    <script src="ASSETS/vendors/nprogress/nprogress.js"></script>
   

    <!-- Custom Theme Scripts -->
    <script src="ASSETS/vendors/build/js/custom.min.js"></script>
  </body>
</html>
