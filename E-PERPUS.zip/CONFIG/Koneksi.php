<?php

   //indentitas Server Database
          $host = "$_SERVER[SERVER_NAME]";
          $user = "root";
          $pass = "";
          $dbnm = "PERPUSTAKAAN";
          $app  = "E-PERPUS";
     
   //Membangun Koneksi Ke Database
          $koneksi = mysqli_connect($host, $user, $pass, $dbnm) or die(mysqli_error($koneksi))

?>