<html>
     <head>
       <title>KONEKSI SERVER</title>
       <link rel="icon" href="../ASSETS/images/icon2.ico">
       <link rel="stylesheet" href="bootstrap.min.css">
     </head>
     <body style="background-color: #046c76;
             color:white;
            ">
     <div class="container text-center">
     <div class="form-signin">
     <img class="mt-5 mb-5" width="180" height="180" src="../ASSETS/images/icon.ico">
     <img class="mt-5 mb-5" width="150" height="155" src="../ASSETS/images/hand.gif">
     <img class="mt-5 mb-5" width="180" height="180" src="../ASSETS/images/db.png">
<?php 

   //indentitas Server Database
          $host = "Localhost";
          $user = "root";
          $pass = "";
          $dbnm = "PERPUSTAKAAN";
          $auth = "M. Ilman Pratama Supardi Putra";
          $date = date('yy');
          $app  = "E-PERPUS";
     
   //Membangun Koneksi Ke Database
          $koneksi = mysqli_connect($host, $user, $pass, $dbnm);
          if ($koneksi) {
               // Jika Koneksi Berhasil
               echo"<script>
                    alert ('CONNECTING SUCCSES TO $dbnm');
                    </script>";
               echo"<h1>SELAMAT ANDA TELAH BERHASIL <br>
                    TERHUBUNG DENGAN SERVER <br>
                    DATABASE ....!<br><br> 
                    IDENTIFIKASI SERVER : </h1><h2>
                        DATABASE : $dbnm
                    <br>HOSTNAME : $host
                    <br>USERNAME : $user</h2><br><br>
                    <h3>Selamat Menggunakan Layanan E-PERPUS <br> Development By $auth <br>Terima Kasih Telah Menggunakan Layanan Kami<br>Harap Patuhi S & K <br>&copy; $date  | $app 
                    </h3>";
          } else {
               // Jika Koneksi Gagal
               die("<script>
                    alert ('CONNECTING FAILED TO $dbnm');
                    </script>" .mysqli_error($koneksi));
          }
          
?>
<br>
<button class="btn btn-info" href="../" value="READ MORE">READ MORE</button>
     <a class="btn btn-outline-info" href="../index.php">NEXT</a>
<br>
<br>
<br>
</div>
</body>
</html>
<?php
print_r(
  $_SERVER['SERVER_PORT']);
print_r(
  $_SERVER['SERVER_NAME']);
print_r(
  $_SERVER['SERVER_SOFTWARE']);
print_r(
  $_SERVER['HTTP_SAVE_DATA']);
print_r($_SERVER);

?>