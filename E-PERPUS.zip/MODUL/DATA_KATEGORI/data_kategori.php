<?php
     //Delete Buku Sesuai Id Buku
     if (isset($_GET['hal'])) {
           if ($_GET['hal'] == "delete") {
               $delete = mysqli_query($koneksi, "DELETE FROM tbl_kategori where ID_KATEGORI='$_GET[id]'");
               if ($delete) {
                    $confirm_delete = true;
               }
          }
     }
     if (isset($_GET['pg'])) {
             $page = $_GET['pg'];
      } else {
             $page = 1;
      }
?>

<!-- read content data buku -->
            <style>
                  .item:hover {
                      border-radius: 8px;
                      border: 0.5px solid ;
                      margin-top: 20px;
                      margin-bottom: 20px;
                      margin-right: 20px;
                      margin-left: 20px;
                      transition: 2.5s;
                      transform: scale(1.5);
                  }
              </style>
    <div class="right_col" role="main">
     <div class="">
      <div class="page-title">
       <div class="title_left">
        <h3></h3>
       </div>

        <div class="title_right">
         <div class="col-md-5 col-sm-5 form-group pull-right top_search">
           <div class="input-group">
            <input type="text" class="form-control" placeholder="Search for...">
              <span class="input-group-btn">
              <button class="btn btn-default" type="button">Go!</button>
              </span>
            </div>
         </div>
        </div>
       </div>

<div class="clearfix"></div>
  <div class="row">
    <div class="col-md-12 col-sm-12  ">
      <div class="x_panel">
       <div class="x_title">
         <h2>DATA KATEGORI BUKU</h2>

                  
<div class="clearfix"></div></div>
  <div class="x_content">
       <?php
            if (isset($confirm_delete)) : ?>
                  <div class="alert alert-info">
                     <a data-dismiss="alert" style="float: right">
                        <i class="fa fa-close"></i>
                     </a>
                       <strong>Information !!</strong> Your Category Has Been Removed From The Electronic Perpustakaan
                   </div>
       <?php endif; ?>
    <form action="?page=kategori&hal=read" method="post">
      <div class="input-group">
       <input type='search' class="form-control input-sm pull-right my-1 my-sm-1" style="width: 150px;"  name='search' placeholder="Search Here ...." autofocus="" onclick="document.getElementById('catatan').innerHTML='Cari Berdasarkan ISBN, JUDUL dan TAGS Book'" autocomplete="off" required>

      
       <div class="input-group-btn">
        <button class="btn btn-info my-1 my-sm-1" name="submits" type="submit" data-toggle="tooltip" data-placement="top" title="Search..."><i class="fa fa-search"></i> Search</button>

        <a href="?page=kategori&hal=read" class="btn btn-warning my-1 my-sm-1"><span class="fa fa-spinner fa-spin" data-toggle="tooltip" data-placement="top" title="Refresh"></span> Refresh </a>
        <a href="?page=buku&hal=create" class="btn btn-success my-1 my-sm-1"   data-toggle="modal" data-target="#popup"><span class="fa fa-tags" data-toggle="tooltip" data-placement="top" title="New Kategori"></span> New Kategori</a>
       </div>
      </div>
     <small id="catatan"></small>                 
    </form>    
<div class="col-sm-12">
 <div class="card-box table-responsive">

   <table class="table table-striped jambo_table bulk_action" style="width:100%">
   <thead>
      <tr>
      <th data-toggle="tooltip" data-placement="top" title="">NO</th>
      <th data-toggle="tooltip" data-placement="top" title="Kode Menyesuaikan dengan Tahun Pembuatan. Contoh : E-PERPUS/KAT/2020.0001">KODE KATEGORI</th>
      <th data-toggle="tooltip" data-placement="top" title="Tanggal Input Otomatis Akan Berisi Hari, Tanggal, dan Waktu Insert Data">TANGGAL INPUT</th>
      <th data-toggle="tooltip" data-placement="top" title="Nama Kategori Harus Berisi Jelas dan Singkat">NAMA KATEGORI</th>
      <th data-toggle="tooltip" data-placement="top" title="Diinput Oleh Akan Berisi Otomatis Sesuai Username Login">DIINPUT OLEH</th>
      <th data-toggle="tooltip" data-placement="top" title="Deskripsi Lokasi Harus Ditulis secara singkat dan terperinci">DESKRIPSI</th>
      <th data-toggle="tooltip" data-placement="top" title="Options Berlaku sesuai akses anda sekarang">OPTIONS</th>   
           
      </tr>
    </thead>

<?php 

          $num_per_page = 5 ;
          $star_form = ($page-1)*$num_per_page;
          $query = "SELECT * FROM tbl_kategori ORDER BY ID_KATEGORI DESC limit $star_form, $num_per_page";
       
          
           if(isset($_POST['search'])) {
            	 $search    = $_POST['search'];
                $query     = "SELECT * FROM  tbl_kategori
            	              where ID_KATEGORI like '%$search%'
            	             or NAMA_KATEGORI like '%$search%' 
            	             ";
                 
             
           }
       $no       = 1;
       $tampil   = mysqli_query($koneksi, $query);
 while($E_PERPUS = mysqli_fetch_array($tampil)) :
         
?>

    <tbody>
      <tr>
      <td><?=$no++?></td>
      <td><?=htmlspecialchars($E_PERPUS['KODE_KATEGORI'])?></td>
      <td><?=htmlspecialchars($E_PERPUS['TANGGAL_INPUT'])?></td>
      <td>
           <a href="#" class="fa fa-tags">
                 <?=htmlspecialchars($E_PERPUS['NAMA_KATEGORI'])?> 
           </a>
      </td>
      <td><?=htmlspecialchars($E_PERPUS['DIINPUT_OLEH'])?></td>
      <td><?=htmlspecialchars($E_PERPUS['DESKRIPSI_OPSIONAL'])?></td>
      <td>
                        
                <div class="btn-group ">
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown"
                      aria-haspopup="true" aria-expanded="false">
                     Actions
                    </button>
                    <div class="dropdown-menu">
                     <a class="dropdown-item" href="?page=kategori&hal=update&id=<?=$E_PERPUS['ID_KATEGORI']?>" class="btn btn-warning"  onclick="return confirm('Do you want to update ? \nKATEGORI : <?=$E_PERPUS['NAMA_KATEGORI']?>')">
                      Edit Kategori
                     </a>
                    
              <?php if($_SESSION['LEVEL'] == "ADMINISTRATOR"){ ?>
                     <a class="dropdown-item" href="?page=kategori&hal=delete&id=<?=$E_PERPUS['ID_KATEGORI']?>" class="btn btn-danger" onclick="return confirm ('Do you want to remove ? \nKATEGORI : <?=$E_PERPUS['NAMA_KATEGORI'];?>')" >
                       Delete Kategori
                     </a>
              <? } ?>
      </td>
      </tr>
      
<?php endwhile;?>

     
      </tbody>
     </table>
     <br>
     <center>
          
          Total Semua Kategori : <?php $sql = mysqli_query($koneksi,"SELECT * FROM tbl_kategori Order By ID_KATEGORI DESC");
            $total = mysqli_num_rows($sql); echo"$total"?>
     </center>
     <ul class="pagination">
       <?php
       
            $pr_query  = "SELECT * FROM tbl_kategori Order By ID_KATEGORI DESC";
            $pr_result = mysqli_query($koneksi, $pr_query);
            $total_record = mysqli_num_rows($pr_result);
            $total_page = ceil($total_record/$num_per_page);
            $pg = 1 ;
                        if ($page > 1) {
                 echo"<li class='page-item'>
                      <a href='?page=kategori&pg=".($page-1)."' class='page-link'>Previous</a>
                      </li>";
            }
            for ($i = 1 ; $i <= $total_page; $i++) {?>
                 <li class="page-item ">
                  <a href="?page=kategori&pg=<?=$i?>" class='page-link'><?=$i ?></a>
                  </li>
           <?php }
            if ($i > 2) {
                      echo"<li class='page-item'>
                      <a href='?page=kategori&pg=".($page+1)."' class='page-link'>Next</a>
                      </li>";
            }
            
       ?>
       </ul>
  


<!-- Modal Popup -->
     
<!-- Modal -->
<div class="modal fade" id="popup" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">NEW KATEGORI</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a href="?page=kategori&hal=create" class="btn btn-success">YES</a>
      </div>
    </div>
  </div>
</div>
<!-- end Modal Popup -->

    </div>
   </div>
  </div>
   </div>
     </div>
       </div>
         </div>
           </div>
        
<!-- end read content data buku  -->