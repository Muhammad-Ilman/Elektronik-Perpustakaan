<h1> Kebijakan Privasi untuk E-PERPUS </h1>

<p> Di E-PERPUS, dapat diakses dari E - PERPUS.INFO, salah satu prioritas utama kami adalah privasi pengunjung kami. Dokumen Kebijakan Privasi ini berisi jenis informasi yang dikumpulkan dan dicatat oleh E-PERPUS dan bagaimana kami menggunakannya. </p>

<p> Jika Anda memiliki pertanyaan tambahan atau memerlukan informasi lebih lanjut tentang Kebijakan Privasi kami, jangan ragu untuk menghubungi kami. </p>

<h2> File Log </h2>

<p> E-PERPUS mengikuti prosedur standar menggunakan file log. File-file ini mencatat pengunjung ketika mereka mengunjungi situs web. Semua perusahaan hosting melakukan ini dan merupakan bagian dari analitik layanan hosting. Informasi yang dikumpulkan oleh file log termasuk alamat protokol internet (IP), jenis browser, Penyedia Layanan Internet (ISP), cap tanggal dan waktu, halaman rujukan / keluar, dan mungkin jumlah klik. Ini tidak terkait dengan informasi apa pun yang dapat diidentifikasi secara pribadi. Tujuan dari informasi tersebut adalah untuk menganalisis tren, mengelola situs, melacak pergerakan pengguna di situs web, dan mengumpulkan informasi demografis. </p>

<h2> Cookies dan Web Beacon </h2>

<p> Seperti situs web lainnya, E-PERPUS menggunakan 'cookie'. Cookies ini digunakan untuk menyimpan informasi termasuk preferensi pengunjung, dan halaman-halaman di situs web yang diakses atau dikunjungi pengunjung. Informasi tersebut digunakan untuk mengoptimalkan pengalaman pengguna dengan menyesuaikan konten halaman web kami berdasarkan jenis browser pengunjung dan / atau informasi lainnya. </p>

<p> Untuk informasi lebih umum tentang cookie, harap baca artikel "What Are Cookies" di <a href="https://www.cookieconsent.com/what-are-cookies/"> situs web Izin Cookie </a> . </p>



<h2> Kebijakan Privasi </h2>

<P> Anda dapat berkonsultasi dengan daftar ini untuk menemukan Kebijakan Privasi untuk masing-masing mitra iklan E-PERPUS. Kebijakan Privasi kami dibuat dengan bantuan <a href="https://www.privacypolicygenerator.org"> Generator Kebijakan Privasi Gratis </a> dan <a href = "https://www.privacypolicyonline.com / privacy-policy-generator / "> Pembuat Kebijakan Privasi Online </a>. </p>

<p> Server iklan atau jaringan iklan pihak ketiga menggunakan teknologi seperti cookie, JavaScript, atau Web Beacon yang digunakan di masing-masing iklan dan tautan yang muncul di E-PERPUS, yang dikirim langsung ke browser pengguna. Mereka secara otomatis menerima alamat IP Anda saat ini terjadi. Teknologi ini digunakan untuk mengukur keefektifan kampanye iklan mereka dan / atau untuk mempersonalisasi konten iklan yang Anda lihat di situs web yang Anda kunjungi. </p>

<p> Perhatikan bahwa E-PERPUS tidak memiliki akses ke atau kontrol atas cookie ini yang digunakan oleh pengiklan pihak ketiga. </p>

<h2> Kebijakan Privasi Pihak Ketiga </h2>

<p> Kebijakan Privasi E-PERPUS tidak berlaku untuk pengiklan atau situs web lain. Karenanya, kami menyarankan Anda untuk berkonsultasi dengan masing-masing Kebijakan Privasi dari server iklan pihak ketiga ini untuk informasi yang lebih rinci. Ini mungkin termasuk praktik dan instruksi mereka tentang cara menyisih dari opsi tertentu. </p>

<p> Anda dapat memilih untuk menonaktifkan cookie melalui opsi browser individu Anda. Untuk mengetahui informasi lebih rinci tentang manajemen cookie dengan browser web tertentu, dapat ditemukan di situs web masing-masing browser. Apa Itu Cookies? </p>

<h2> Informasi Anak-anak </h2>

<p> Bagian lain dari prioritas kami adalah menambahkan perlindungan untuk anak-anak saat menggunakan internet. Kami mendorong orang tua dan wali untuk mengamati, berpartisipasi, dan / atau memantau dan membimbing aktivitas online mereka. </p>

<p> E-PERPUS tidak dengan sengaja mengumpulkan Informasi Identifikasi Pribadi apa pun dari anak-anak di bawah usia 13 tahun. Jika menurut Anda anak Anda memberikan informasi semacam ini di situs web kami, kami sangat menganjurkan Anda untuk segera menghubungi kami dan kami akan melakukan upaya terbaik untuk segera menghapus informasi tersebut dari catatan kami. </p>

<h2> Hanya Kebijakan Privasi Online </h2>

<p> Kebijakan Privasi ini hanya berlaku untuk aktivitas online kami dan berlaku untuk pengunjung situs web kami sehubungan dengan informasi yang mereka bagikan dan / atau kumpulkan di E-PERPUS. Kebijakan ini tidak berlaku untuk informasi apa pun yang dikumpulkan secara offline atau melalui saluran selain situs web ini. </p>

<h2> Persetujuan </h2>

<p> Dengan menggunakan situs web kami, Anda dengan ini menyetujui Kebijakan Privasi kami dan menyetujui Syarat dan Ketentuannya. </p>