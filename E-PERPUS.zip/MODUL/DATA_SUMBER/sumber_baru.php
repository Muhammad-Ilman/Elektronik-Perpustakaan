<!-- page content -->
<?php
/*KETIKA TOMBOL SEND DITEKAN*/
if (isset($_POST['send'])) {
    if ($_GET['hal'] == "update") {
        $update = mysqli_query($koneksi, "UPDATE `tbl_sumber` SET
          			SUMBER_PENGADAAN='$_POST[SUMBER_PENGADAAN]',
                         DESKRIPSI_OPSIONAL='$_POST[DESKRIPSI_OPSIONAL]'

                         WHERE ID_PENGADAAN='$_GET[id]'
                         ");
        if ($update) {
            echo "<script>
                      alert ('Sumber Pengadaan Telah Behasil Di update');
                      document.location='?page=sumber';
                        </script>";
        }


    } elseif ($_GET['hal'] == "create") {

        /*CEK DATA KE DATABASE*/
        $SUMBER_PENGADAAN = $_POST['SUMBER_PENGADAAN'];
        $AUTH_SUMBER = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tbl_sumber WHERE SUMBER_PENGADAAN='$SUMBER_PENGADAAN'"));
        if ($AUTH_SUMBER > 0) {
                 $auth = true;

            /*END CEK DATA*/
        } else {

            $insert = mysqli_query($koneksi, "INSERT INTO `tbl_sumber` VALUES (
               '',
               '$_POST[KODE_PENGADAAN]',
               '$_POST[TANGGAL_INPUT]',
               '$_POST[DIINPUT_OLEH]',
               '$SUMBER_PENGADAAN',
               '$_POST[DESKRIPSI_OPSIONAL]'
               )");
         
            if ($insert) {
                echo "<script>
                      alert ('sumber has been created');
                      document.location='?page=sumber';
                      </script>";
            }
        }
    }
}
/*END TOMBOL SEND*/



/*KODE OTOMATIS*/
$sql = "SELECT max(ID_PENGADAAN) as max_id FROM tbl_sumber WHERE ID_PENGADAAN ORDER BY ID_PENGADAAN DESC LIMIT 1";
$query1 = mysqli_query($koneksi, $sql);
$E_PERPUS = mysqli_fetch_assoc($query1);
$getid = $E_PERPUS['max_id'];
$no = substr($getid, -5, 5);
$no = (int) $no;
$no = $no + 1;
$nid = sprintf("%05s", $no);
/*END KODE OTOMATIS*/

/*MENAMPILKAN DATA YANG AKAN DI-UPDATE*/
$tampil = mysqli_query($koneksi, "SELECT * from `tbl_sumber` WHERE ID_PENGADAAN='$_GET[id]'");
$E_PERPUS = mysqli_fetch_array($tampil);
if ($E_PERPUS) {
    $vnama_sumber = $E_PERPUS['SUMBER_PENGADAAN'];
    $vdesop       = $E_PERPUS['DESKRIPSI_OPSIONAL'];

}

?>

<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3> </h3>
            </div>

            <div class="title_right">
                <div class="col-md-5 col-sm-5 form-group pull-right top_search">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2><span class="fa fa-tag"></span> FORM INPUT SUMBER PENGADAAN BARU</h2>
                        <ul class="nav navbar-right panel_toolbox">

                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <br>

                        <div class="row">
                            <?php
                            if (isset($auth)) : ?>
                            &ensp;&ensp;&ensp;
                            <div class="alert alert-warning col-md-5 col-md-5 col-sm-5 form-group pull-right">
                                <a data-dismiss="alert" style="float: right">
                                    <i class="fa fa-close"></i>
                                </a>
                                <strong>Warning !!</strong> Sumber Name Already Exist
                            </div>
                            <?php endif; ?>
                        </div>

                        <form action="" method="POST" enctype="multipart/form-data" class="form-horizontal form-label-left">
                            <div class="item form-group">
                                <label class="control-label col-md-3  " for="KODE_PENGADAAN"> KODE PENGADAAN <span class="required">*</span>
                                </label>
                                <div class="col-md-7 col-sm-7">
                                    <input type="text" id="KODE_PENGADAAN" name="KODE_PENGADAAN" class="form-control "placeholder="" value="E-PERPUS/S.P/<?=date("yy.").$nid; ?>" readonly>

                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3" for="TANGGAL_INPUT"> TANGGAL INPUT <span class="required">*</span>
                                </label>
                                <div class="col-md-7 col-sm-7">
                                    <input type="text" id="TANGGAL_INPUT" name="TANGGAL_INPUT" required="required" class="form-control" value="<?=date("l, d-m-y h:i:s"); ?>" readonly>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="control-label col-md-3" for="DIINPUT_OLEH"> DIINPUT OLEH <span class="required">*</span>
                                </label>
                                <div class="col-md-7 col-sm-7">
                                    <input type="text" id="DIINPUT_OLEH" name="DIINPUT_OLEH" required="required" class="form-control"value="<?=$_SESSION['username'] ?>" readonly="" autocomplete="off">

                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="control-label col-md-3" for="SUMBER_PENGADAAN"> SUMBER PENGADAAN <span class="required">*</span>
                                </label>
                                <div class="col-md-7 col-sm-7">
                                    <input type="text" id="SUMBER_PENGADAAN" name="SUMBER_PENGADAAN" required="required" class="form-control"value="<?=$vnama_sumber ?>" autocomplete="off" onclick="document.getElementById('cname').innerHTML='Contoh :  Rak - Pembelian, Sumbangan, Denda dst'" data-toggle="tooltip" data-placement="top" title="This Value is Required !">

                                    <small id="cnam"></small>

                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="control-label col-md-3" for="DESKRIPSI_OPSIONAL"> DESKRIPSI OPSIONAL <span class="required">*</span>
                                </label>
                                <div class="col-md-7 col-sm-7">

                                    <textarea name="DESKRIPSI_OPSIONAL" id="DESKRIPSI_OPSIONAL" rows="8"class="form-control" onclick="document.getElementById('cdesof').innerHTML='Contoh :  Pembelian dengan menggunakan dana dari ....'" required="" data-toggle="tooltip" data-placement="top" title="This Value is Required !"><?=$vdesop?></textarea>
                                    <small id="cdesof"></small>
                                </div>
                            </div>


                            <br>
                            <div class="item form-group ">
                                <div class="container text-center">
                                    <input type="checkbox" class="my-2" id="sdk" required>
                                    <label class="" for="sdk"> I Have read and agree <a href=""><a href="" data-toggle="modal" data-target="#SDK"><strong>Terms and condition</strong></a> in Elektronik Perpustakaan application</label>
                                    </div>
                                </div>

                                <div class="ln_solid"></div>
                                <div class="item form-group">
                                    <div class="col-md-7 col-sm-7 offset-md-3">
                                        <a href="?page=sumber" class="btn btn-dark" type="button"><i class="fa fa-arrow-circle-o-left"> </i> BACK </a>
                                        <a href="" class="btn btn-secondary" type="reset">RESET</a>
                                        <button type="submit" name="send" class="btn btn-success">SEND</button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>


            </div>
        </div>


    </div>
</div>
</div>

<!-- /page content -->

<!-- Modal Popup -->

<div class="modal fade" id="SDK" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel">New Book</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">

<p>
Dengan Mengklik yes anda berarti menerima dan menyetujui syarat dan ketentuan aplikasi elektronik Perpustakaan
</p>

</div>
<div class="modal-footer">
<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>

</div>
</div>
</div>
</div>

<!-- end Modal Popup -->