<!-- Elektronik Perpustakaan Dashboard Page -->
      <!-- chart -->
    <script src="ASSETS/vendors/chart/chart.js"></script>
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <style>
                  .item:hover {
                     
                      transition: 2.5s;
                      transform: scale(1.1);

                  }
              </style>
              <div class="col-lg col-sm-3 item">
                <div class="x_panel bg-green" style="border-radius:10px;">
                  
                    <h2><center> TOTAL BUKU</center></h2>
                      <div class="ln_solid"></div>  
                    <div class="clearfix"></div>
                  
                  <div class="x_content">
                     <i class="fa fa-book fa-3x" style="float:left">
                       <strong>                                <?php 
                       $sql = "select * from tbl_buku order by ID_BUKU desc";
                       $tampil = mysqli_query($koneksi, $sql);
                        $total_buku=mysqli_num_rows($tampil);
                        echo($total_buku);
                        
                    ?></strong>&ensp;
                     </i>
                  <h3 class="" style="float: left"></h3> 
                    <p style=""><br>Buku
                      <a href="?page=buku&hal=read" 
                      style="float: right;color: white">
                      <i class="fa fa-external-link-square"></i> 
                      </a>
                    </p>
                  </div>
                </div>
              </div>
              
              <div class="col-md-3 col-sm-3 item">
                <div class="x_panel bg-warning text-white"style="border-radius:10px">
                  
                    <h2><center>TOTAL SIRKULASI</center></h2>
                      <div class="ln_solid"></div>  
                    <div class="clearfix"></div>
                  
                  <div class="x_content">
                     <i class="fa fa-refresh fa-3x" style="float:left">
                       <strong>0</strong>&ensp;
                     </i>
                  <h3 class="" style="float: left"></h3> 
                    <p style=""><br>Sirkulasi
                      <a href="?page=sirkulasi" class="fa fa-external-link-square" style="float: right;color: white;"></a>
                    </p>
                  </div>
                </div>
              </div>
          
              <div class="col-md-3 col-sm-3 item">
                <div class="x_panel bg-info text-white" style="border-radius:10px">
                  
                    <h2><center>TOTAL USER</center></h2>
                      <div class="ln_solid"></div>  
                    <div class="clearfix"></div>
                  
                  <div class="x_content">
                                         
                     <i class="fa fa-users fa-3x" style="float:left">
                       <strong>                                <?php 
                       $sql = "select * from tbl_users order by ID_SISWA desc";
                       $tampil = mysqli_query($koneksi, $sql);
                        $total_buku=mysqli_num_rows($tampil);
                        echo($total_buku);
                    ?></strong>&ensp;
                     </i>
                  <h3 class="" style="float: left"></h3> 
                    <p style=""><br>User
                      <a href="?page=users" class="fa fa-external-link-square" style="float: right;color: white;"></a>
                    </p>
                    </div>
                </div>
              </div>
              <div class="col-md-3 col-sm-3 item">
                <div class="x_panel alert-info" style="border-radius:10px">
                  
                    <h2><center>TOTAL KUNJUNGAN</center></h2>
                      <div class="ln_solid"></div>  
                    <div class="clearfix"></div>
                  
                  <div class="x_content">
                                         
                     <i class="fa fa-university fa-3x" style="float:left">
                       <strong>                                <?php 
                       $sql = "select * from tbl_users order by ID_SISWA desc";
                       $tampil = mysqli_query($koneksi, $sql);
                        $total_buku=mysqli_num_rows($tampil);
                        echo($total_buku);
                    ?></strong>&ensp;
                     </i>
                  <h3 class="" style="float: left"></h3> 
                    <p style=""><br>kunjungan
                      <a href="?page=users" class="fa fa-external-link-square" style="float: right;color: white;"></a>
                    </p>
                    </div>
                </div>
              </div>
              
            </div>

            <div class="row">
              
              <div class="col-md-3 col-sm-3 item">
                <div class="x_panel bg-purple text-white" style="border-radius:10px">
                  
                    <h2><center> TOTAL RAK BUKU</center></h2>
                      <div class="ln_solid"></div>  
                    <div class="clearfix"></div>
                  
                  <div class="x_content">
                     <i class="fa fa-tasks fa-3x" style="float:left">
                       <strong>                                <?php 
                       $sql = "select * from tbl_lokasi order by ID_LOKASI desc";
                       $tampil = mysqli_query($koneksi, $sql);
                        $total_buku=mysqli_num_rows($tampil);
                        echo($total_buku);
                    ?></strong>&ensp;
                     </i>
                  <h3 class="" style="float: left"></h3> 
                    <p style=""><br>Rak Buku
                      <a href="?page=lokasi" 
                      style="float: right;color: white">
                      <i class="fa fa-external-link-square"></i> 
                      </a>
                    </p>
                  </div>
                </div>
              </div>
              
              <div class="col-md-3 col-sm-3 item">
                <div class="x_panel alert-danger text-white"style="border-radius:10px">
                  
                    <h2><center>TOTAL KATEGORI</center></h2>
                      <div class="ln_solid"></div>  
                    <div class="clearfix"></div>
                  
                  <div class="x_content">
                     <i class="fa fa-tags fa-3x " style="float:left">
                      <strong>                                <?php 
                       $sql = "select * from tbl_kategori order by ID_KATEGORI desc";
                       $tampil = mysqli_query($koneksi, $sql);
                        $total_kategori=mysqli_num_rows($tampil);
                        echo($total_kategori);
                    ?></strong>&ensp;
                     </i>
                  <h3 class="" style="float: left;"></h3> 
                    <p style=""><br>Kategori
                      <a href="?page=kategori" class="fa fa-external-link-square" style="float: right; color: white;"></a>
                    </p>
                  </div>
                </div>
              </div>
          
              <div class="col-md-3 col-sm-3 item">
                <div class="x_panel bg-primary text-white" style="border-radius:10px">
                  
                    <h2><center>TOTAL SUMBER BUKU</center></h2>
                      <div class="ln_solid"></div>  
                    <div class="clearfix"></div>
                  
                  <div class="x_content">
                                         
                     <i class="fa fa-hdd-o fa-3x" style="float:left">
                   <strong>                                <?php 
                       $sql = "select * from tbl_sumber order by SUMBER_PENGADAAN desc";
                       $tampil = mysqli_query($koneksi, $sql);
                        $total_buku=mysqli_num_rows($tampil);
                        echo($total_buku);
                    ?></strong>&ensp;
                     </i>
                  <h3 class="" style="float: left"></h3> 
                    <p style=""><br>Sumber
                      <a href="?page=sumber" class="fa fa-external-link-square" style="float: right; color: white;"></a>
                    </p>
                    </div>
                </div>
              </div>
              
              <div class="col-md-3 col-sm-3 item">
                <div class="x_panel alert-info text-white" style="border-radius:10px">
                  
                    <h2><center>TOTAL PEMINJAMAN</center></h2>
                      <div class="ln_solid"></div>  
                    <div class="clearfix"></div>
                  
                  <div class="x_content">
                                         
                     <i class="fa fa-cloud-upload fa-3x" style="float:left">
                   <strong>                                <?php 
                       $sql = "select * from tbl_admin order by USERNAME desc";
                       $tampil = mysqli_query($koneksi, $sql);
                        $total_buku=mysqli_num_rows($tampil);
                        echo($total_buku);
                    ?></strong>&ensp;
                     </i>
                  <h3 class="" style="float: left"></h3> 
                    <p style=""><br>Terpinjam
                      <a href="?page=sumber" class="fa fa-external-link-square" style="float: right; color: white;"></a>
                    </p>
                    </div>
                </div>
              </div>
              
            </div>
            
            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-line-chart"></i>
                      <strong>GRAFIK PENGUNJUNG PERPUSTAKAAN</strong>
                    </h2>

                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                         <style>
    canvas{
      -moz-user-select: none;
      -webkit-user-select: none;
      -ms-user-select: none;
    }
    #chartjs-tooltip {
      opacity: 1;
      position: absolute;
      background: rgba(0, 0, 0, .7);
      color: white;
      border-radius: 3px;
      -webkit-transition: all .1s ease;
      transition: all .1s ease;
      pointer-events: none;
      -webkit-transform: translate(-50%, 0);
      transform: translate(-50%, 0);
    }

    .chartjs-tooltip-key {
      display: inline-block;
      width: 10px;
      height: 10px;
    }
  </style>
  <div id="canvas-holder1" style="width:75%;">
    <canvas id="chart1"></canvas>
  </div>
  <script>
    window.count = 0;
    Chart.defaults.global.pointHitDetectionRadius = 1;
    var customTooltips = function(tooltip) {

      // Tooltip Element
      var tooltipEl = $('#chartjs-tooltip');

      if (!tooltipEl[0]) {
        $('body').append('<div id="chartjs-tooltip"></div>');
        tooltipEl = $('#chartjs-tooltip');
      }

      // Hide if no tooltip
      if (!tooltip.opacity) {
        tooltipEl.css({
          opacity: 0
        });
        $('.chartjs-wrap canvas')
          .each(function(index, el) {
            $(el).css('cursor', 'default');
          });
        return;
      }

      $(this._chart.canvas).css('cursor', 'pointer');

      // Set caret Position
      tooltipEl.removeClass('above below no-transform');
      if (tooltip.yAlign) {
        tooltipEl.addClass(tooltip.yAlign);
      } else {
        tooltipEl.addClass('no-transform');
      }

      // Set Text
      if (tooltip.body) {
        var innerHtml = [
          (tooltip.beforeTitle || []).join('\n'), (tooltip.title || []).join('\n'), (tooltip.afterTitle || []).join('\n'), (tooltip.beforeBody || []).join('\n'), (tooltip.body || []).join('\n'), (tooltip.afterBody || []).join('\n'), (tooltip.beforeFooter || [])
          .join('\n'), (tooltip.footer || []).join('\n'), (tooltip.afterFooter || []).join('\n')
        ];
        tooltipEl.html(innerHtml.join('\n'));
      }

      // Find Y Location on page
      var top = 0;
      if (tooltip.yAlign) {
        if (tooltip.yAlign == 'above') {
          top = tooltip.y - tooltip.caretHeight - tooltip.caretPadding;
        } else {
          top = tooltip.y + tooltip.caretHeight + tooltip.caretPadding;
        }
      }

      var position = $(this._chart.canvas)[0].getBoundingClientRect();

      // Display, position, and set styles for font
      tooltipEl.css({
        opacity: 1,
        width: tooltip.width ? (tooltip.width + 'px') : 'auto',
        left: position.left + tooltip.x + 'px',
        top: position.top + top + 'px',
        fontFamily: tooltip._fontFamily,
        fontSize: tooltip.fontSize,
        fontStyle: tooltip._fontStyle,
        padding: tooltip.yPadding + 'px ' + tooltip.xPadding + 'px',
      });
    };
    var randomScalingFactor = function() {
      return Math.round(Math.random() * 100);
    };
    var lineChartData = {
      labels: ["January", "February", "March", "April", "May", "June", "July","Agustus"],
      datasets: [{
        label: "My First dataset",
        backgroundColor: "rgba(167,227,215,0.1)",
        data: [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(),10]
      }, {
        label: "My Second dataset",
        backgroundColor: "rgba(154,189,195,0.1)",
        data: [randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(), randomScalingFactor(),150]
      }]
    };

    window.onload = function() {
      var chartEl = document.getElementById("chart1");
      window.myLine = new Chart(chartEl, {
        type: 'line',
        data: lineChartData,
        options: {
          title:{
            display:true,
            text:'GRAFIK PERPUSTAKAAN SMP NEGERI 3 CIBEBER'
          },
          tooltips: {
            enabled: true,
            custom: customTooltips
          }
        }
      });
    };
  </script>

                  </div>
                </div>
              </div>
              
            </div>

        <?php if( $_SESSION['LEVEL'] == "ADMINISTRATOR" || $_SESSION['LEVEL']== "OPERATOR") { ?>
        
            <div class="row">
                  <div class="col-md-7 col-sm-7  ">
                    <div class="x_panel">
                      <div class="x_title">
                        <h2><i class="fa fa-bell"></i> Notifications</h2>
                        <ul class="nav navbar-right panel_toolbox">
                          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                          </li>
                          <li class="dropdown pull-left">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">Settings 1</a>
                                <a class="dropdown-item" href="#">Settings 2</a>
                              </div>
                          </li>
                          <li><a class="close-link"><i class="fa fa-close"></i></a>
                          </li>
                        </ul>
                        <div class="clearfix"></div>
                      </div>
                      <div class="x_content">
    
        <?php
           
            $query = "select * from tbl_buku order by ID_BUKU desc limit 1";
            $tampil = mysqli_query($koneksi, $query);
      while($E_PERPUS   = mysqli_fetch_array($tampil)) :
    
         ?>           
                 <div class="alert alert-success">
                    <a data-dismiss="alert" style="float: right">
                       <i class="fa fa-close"></i>
                    </a>
                      <strong><?=$E_PERPUS['JUDUL_BUKU'];?></strong>, Baru terdaftar di elekrtonik perpustakaan
                  </div>
             
             <?php endwhile; ?>             
        <?php
           
            $query = "select * from tbl_buku order by ID_BUKU desc limit 1";
            $tampil = mysqli_query($koneksi, $query);
      while($E_PERPUS   = mysqli_fetch_array($tampil)) :
    
         ?>           
                 <div class="alert e alert-warning">
                    <a data-dismiss="alert" style="float: right">
                       <i class="fa fa-close"></i>
                    </a>
                      <strong><?=$E_PERPUS['JUDUL_BUKU'];?></strong>, Baru terdaftar di elekrtonik perpustakaan
                  </div>
             
             <?php endwhile; ?>             
        <?php
           
            $query = "select * from tbl_buku order by ID_BUKU desc limit 1";
            $tampil = mysqli_query($koneksi, $query);
      while($E_PERPUS   = mysqli_fetch_array($tampil)) :
    
         ?>           
                 <div class="alert alert-info">
                    <a data-dismiss="alert" style="float: right">
                       <i class="fa fa-close"></i>
                    </a>
                      <strong><?=$E_PERPUS['JUDUL_BUKU'];?></strong>, Baru terdaftar di elekrtonik perpustakaan
                  </div>
             
             <?php endwhile; ?>             
        <?php
           
            $query = "select * from tbl_kategori order by ID_KATEGORI desc limit 1";
            $tampil = mysqli_query($koneksi, $query);
      while($E_PERPUS   = mysqli_fetch_array($tampil)) :
    
         ?>           
                 <div class="alert bg-primary">
                    <a data-dismiss="alert" style="float: right">
                       <i class="fa fa-close" style="color: white;"></i>
                    </a>
                      <strong><?=$E_PERPUS['NAMA_KATEGORI'];?></strong>, Kategori terbaru di elekrtonik perpustakaan
                  </div>
             
             <?php endwhile; ?>             
        <?php
           
            $query = "select * from tbl_kategori order by ID_KATEGORI desc limit 1";
            $tampil = mysqli_query($koneksi, $query);
      while($E_PERPUS   = mysqli_fetch_array($tampil)) :
    
         ?>           
                 <div class="alert bg-purple">
                    <a data-dismiss="alert" style="float: right">
                       <i class="fa fa-close"></i>
                    </a>
                      <strong><?=$E_PERPUS['NAMA_KATEGORI'];?></strong>, Kategori terbaru di elekrtonik perpustakaan
                  </div>
             
             <?php endwhile; ?>             
        <?php
           
            $query = "select * from tbl_lokasi order by ID_LOKASI desc limit 1";
            $tampil = mysqli_query($koneksi, $query);
      while($E_PERPUS   = mysqli_fetch_array($tampil)) :
    
         ?>           
                 <div class="alert alert-success">
                    <a data-dismiss="alert" style="float: right">
                       <i class="fa fa-close"></i>
                    </a>
                      <strong><?=$E_PERPUS['NAMA_LOKASI'];?></strong>, Lokasi Rak Baru Terdaftar di elekrtonik perpustakaan
                  </div>
             
             <?php endwhile; ?>             
        <?php
           
            $query = "select * from tbl_lokasi order by ID_LOKASI desc limit 1";
            $tampil = mysqli_query($koneksi, $query);
      while($E_PERPUS   = mysqli_fetch_array($tampil)) :
    
         ?>           
                 <div class="alert alert-info">
                    <a data-dismiss="alert" style="float: right">
                       <i class="fa fa-close"></i>
                    </a>
                      <strong><?=$E_PERPUS['NAMA_LOKASI'];?></strong>, Lokasi Rak Baru Terdaftar di elekrtonik perpustakaan
                  </div>
             
             <?php endwhile; ?>             
        <?php
           
            $query = "select * from tbl_buku order by PENERBIT desc limit 1";
            $tampil = mysqli_query($koneksi, $query);
      while($E_PERPUS   = mysqli_fetch_array($tampil)) :
    
         ?>           
                 <div class="alert alert-success">
                    <a data-dismiss="alert" style="float: right">
                       <i class="fa fa-close"></i>
                    </a>
                      <strong><?=$E_PERPUS['PENERBIT'];?></strong>, Penerbit baru di elekrtonik perpustakaan
                  </div>
             
             <?php endwhile; ?>             
    
            
    
    
                      </div>
                    </div>
                  </div>
                        <div class="col-md-5 col-sm-5  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Pie Area</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <div id="main"></div>

                  </div>
                </div>
              </div>
                  <div class="col-md-5 col-sm-5  ">
                    <div class="x_panel">
                      <div class="x_title">
                        <h2><i class="fa fa-system"></i> Sistem Device</h2>
                        <ul class="nav navbar-right panel_toolbox">
                          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                          </li>
                          <li class="dropdown pull-left">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">Settings 1</a>
                                <a class="dropdown-item" href="#">Settings 2</a>
                              </div>
                          </li>
                          <li><a class="close-link"><i class="fa fa-close"></i></a>
                          </li>
                        </ul>
                        <div class="clearfix"></div>
                      </div>
                        <div class="x_content">
                <div class="col  bg-white">
                  <div class="x_title">
                    <h2>Top Campaign Performance</h2>
                    <div class="clearfix"></div>
                  </div>

                  <div class="col-md-12 col-sm-12 ">
                    <div>
                      <p>Facebook Campaign</p>
                      <div class="">
                        <div class="progress progress_sm" style="width: 76%;">
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="80"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <p>Twitter Campaign</p>
                      <div class="">
                        <div class="progress progress_sm" style="width: 76%;">
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="60"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 col-sm-12 ">
                    <div>
                      <p>Conventional Media</p>
                      <div class="">
                        <div class="progress progress_sm" style="width: 76%;">
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="40"></div>
                        </div>
                      </div>40%
                    </div>
                    <div>
                      <p>Bill boards</p>
                      <div class="">
                        <div class="progress progress_sm" style="width: 76%;">
                          <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="99"></div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
                        </div>
                    </div>
                  </div>
                </div>
        <? } ?>
                
            <div class="row">
                <div class="col-md-12 col-sm-12 ">
                      <div class="x_panel">
                        <div class="x_title">
                          <h2><i class="fa fa-map-marker"></i>  World Global Maps</h2>
                          <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                            <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                  <a class="dropdown-item" href="#">Settings 1</a>
                                  <a class="dropdown-item" href="#">Settings 2</a>
                                </div>
                            </li>
                            <li><a class="close-link"><i class="fa fa-close"></i></a>
                            </li>
                          </ul>
                          <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                          <div class="dashboard-widget-content">
                  
                            <div id="world-map-gdp" class="col-md-12 col-sm-12 " style="height:230px;"></div>
                          </div>
                            <br>
                            <br>
                            <br>
                        </div>
                      </div>
                    </div>
                 </div>
             
        <?php if( $_SESSION['LEVEL'] == "ADMINISTRATOR" || $_SESSION['LEVEL'] == "OPERATOR") { ?>
        
            <div class="row">
                <div class="col-md-5 col-sm-5 ">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>Recent Activities <small>Sessions</small></h2>
                      <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                        <li class="dropdown">
                          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                              <a class="dropdown-item" href="#">Settings 1</a>
                              <a class="dropdown-item" href="#">Settings 2</a>
                            </div>
                        </li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                        </li>
                      </ul>
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                      <div class="dashboard-widget-content">
    
                        <ul class="list-unstyled timeline widget">
                          <li>
                            <div class="block">
                              <div class="block_content">
                                <h2 class="title">
                                                  <a>Who Needs Sundance When You’ve Got&nbsp;Crowdfunding?</a>
                                              </h2>
                                <div class="byline">
                                  <span>13 hours ago</span> by <a>Jane Smith</a>
                                </div>
                                <p class="excerpt">Film festivals used to be do-or-die moments for movie makers. They were where you met the producers that could fund your project, and if the buyers liked your flick, they’d pay to Fast-forward and… <a>Read&nbsp;More</a>
                                </p>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class="block">
                              <div class="block_content">
                                <h2 class="title">
                                                  <a>Who Needs Sundance When You’ve Got&nbsp;Crowdfunding?</a>
                                              </h2>
                                <div class="byline">
                                  <span>13 hours ago</span> by <a>Jane Smith</a>
                                </div>
                                <p class="excerpt">Film festivals used to be do-or-die moments for movie makers. They were where you met the producers that could fund your project, and if the buyers liked your flick, they’d pay to Fast-forward and… <a>Read&nbsp;More</a>
                                </p>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class="block">
                              <div class="block_content">
                                <h2 class="title">
                                                  <a>Who Needs Sundance When You’ve Got&nbsp;Crowdfunding?</a>
                                              </h2>
                                <div class="byline">
                                  <span>13 hours ago</span> by <a>Jane Smith</a>
                                </div>
                                <p class="excerpt">Film festivals used to be do-or-die moments for movie makers. They were where you met the producers that could fund your project, and if the buyers liked your flick, they’d pay to Fast-forward and… <a>Read&nbsp;More</a>
                                </p>
                              </div>
                            </div>
                          </li>
                          <li>
                            <div class="block">
                              <div class="block_content">
                                <h2 class="title">
                                                  <a>Who Needs Sundance When You’ve Got&nbsp;Crowdfunding?</a>
                                              </h2>
                                <div class="byline">
                                  <span>13 hours ago</span> by <a>Jane Smith</a>
                                </div>
                                <p class="excerpt">Film festivals used to be do-or-die moments for movie makers. They were where you met the producers that could fund your project, and if the buyers liked your flick, they’d pay to Fast-forward and… <a>Read&nbsp;More</a>
                                </p>
                              </div>
                            </div>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
    
    
    
                    <!-- Start to do list -->
                    <div class="col-md-7 col-sm-7 ">
                      <div class="x_panel">
                        <div class="x_title">
                          <h2>To Do List <small>Sample tasks</small></h2>
                          <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                            <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                  <a class="dropdown-item" href="#">Settings 1</a>
                                  <a class="dropdown-item" href="#">Settings 2</a>
                                </div>
                            </li>
                            <li><a class="close-link"><i class="fa fa-close"></i></a>
                            </li>
                          </ul>
                          <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
    
                          <div class="">
                            <ul class="to_do">
                              <li class="item">
                                <p>
                                  <input type="checkbox" class="flat"> Schedule meeting with new client </p>
                              </li>
                              <li class="item">
                                <p>
                                  <input type="checkbox" class="flat"> Create email address for new intern</p>
                              </li>
                              <li class="item">
                                <p>
                                  <input type="checkbox" class="flat"> Have IT fix the network printer</p>
                              </li>
                              <li class="item">
                                <p>
                                  <input type="checkbox" class="flat"> Copy backups to offsite location</p>
                              </li>
                              <li class="item">
                                <p>
                                  <input type="checkbox" class="flat"> Food truck fixie locavors mcsweeney</p>
                              </li>
                              <li class="item">
                                <p>
                                  <input type="checkbox" class="flat"> Food truck fixie locavors mcsweeney</p>
                              </li>
                              <li class="item">
                                <p>
                                  <input type="checkbox" class="flat"> Create email address for new intern</p>
                              </li>
                              <li class="item">
                                <p>
                                  <input type="checkbox" class="flat"> Have IT fix the network printer</p>
                              </li>
                              <li class="item">
                                <p>
                                  <input type="checkbox" class="flat"> Rajin Selalu Backup Database </p>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- End to do list -->
                    
              </div>
              
        <? } ?>
              


            
          </div>
        </div>
        <script>           
         function makeChart () {
                var main = document.getElementById('main');
                var div = document.createElement('div');
                var width = document.body.clientWidth;
                div.style.cssText = width + 'px; height:250px';
                main.appendChild(div);
                return echarts.init(div);
            }
          function makePie() {
                var chart = makeChart();
                chart.setOption({
                    legend: {
                        data:['Kucing','Anjing','kelinci','Burung','ikan','sapi']
                    },
                    tooltip: {

                    },
                    series: [{
                        name: 'pie',
                        type: 'pie',
                        selectedMode: 'single',
                        hoverAnimation: true,
                        selectedOffset: 15,
                        clockwise: true,
                        data:[
                            {value:335, name:'Anjing'},
                            {value:115, name:'kelinci'},
                            {value:234, name:'Burung'},
                            {value:135, name:'Ikan'},
                            {value:1360, name:'sapi',},
                            {value:1548, name:'Kucing'}
                        ]
                    }]
                });
            }

            setTimeout(function () {
                makePie();
            }, 150);
</script>
        <script src="chart.js"></script>

<!-- E - PERPUS End content -->