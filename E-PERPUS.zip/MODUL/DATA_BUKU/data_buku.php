<?php

     //Delete Buku Sesuai Id Buku
     if (isset($_GET['hal'])) {
           if ($_GET['hal'] == "delete") {
               $delete = mysqli_query($koneksi, "DELETE FROM tbl_buku where ID_BUKU='$_GET[id]'");
               if ($delete) {
                    $confirm_delete = true;
               }
          }
     }
     if (isset($_GET['pg'])) {
             $page = $_GET['pg'];
      } else {
             $page = 1;
             
      }
?>

<!-- read content data buku -->
            <style>
                  .item:hover {
                  
                     
                      border-radius: 8px;
                      border: 0.5px solid ;
                      margin-top: 20px;
                      margin-bottom: 20px;
                      margin-right: 20px;
                      margin-left: 20px;
                      transition: 2.5s;
                      transform: scale(1.5);

                  }
              </style>
    <div class="right_col" role="main">
     <div class="">
      <div class="page-title">
       <div class="title_left">
        <h3></h3>
       </div>

        <div class="title_right">
         <div class="col-md-5 col-sm-5 form-group pull-right top_search">
           <div class="input-group">
            <input type="text" class="form-control" placeholder="Search for...">
              <span class="input-group-btn">
              <button class="btn btn-default" type="button">Go!</button>
              </span>
            </div>
         </div>
        </div>
       </div>

<div class="clearfix"></div>
  <div class="row">
    <div class="col-md-12 col-sm-12  ">
      <div class="x_panel">
       <div class="x_title">
         <h2>DATA BUKU TERDAFTAR DI E-PERPUS</h2>

                  
<div class="clearfix"></div></div>
  <div class="x_content">
       <?php
            if (isset($confirm_delete)) : ?>
                  <div class="alert alert-info">
                     <a data-dismiss="alert" style="float: right">
                        <i class="fa fa-close"></i>
                     </a>
                       <strong>Information !!</strong> Your Book Has Been Removed From The Electronic Perpustakaan
                   </div>
       <?php endif; ?>
    <form action="?page=buku&hal=read" method="post">
      <div class="input-group">
       <input type='search' class="form-control input-sm pull-right my-1 my-sm-1" style="width: 150px;"  name='search' placeholder="Search Here ...." autofocus="" onclick="document.getElementById('catatan').innerHTML='Cari Berdasarkan ISBN, JUDUL dan TAGS Book'" autocomplete="off" required>

      
       <div class="input-group-btn">
        <button class="btn btn-info my-1 my-sm-1" name="submits" type="submit" data-toggle="tooltip" data-placement="top" title="Search..."><i class="fa fa-search"></i> Search</button>

        <a href="?page=buku" class="btn btn-warning my-1 my-sm-1"><span class="fa fa-spinner fa-spin" data-toggle="tooltip" data-placement="top" title="Refresh Data"></span> Refresh Book</a>
        <a href="?page=buku&hal=create" class="btn btn-success my-1 my-sm-1" data-toggle="modal" data-target="#New-Book"><span class="fa fa-book" data-target="#New-Book" data-toggle="tooltip" data-placement="top" title="New Book"></span> New Book</a>
       </div>
      </div>
     <small id="catatan"></small>                 
    </form>    
<div class="col-sm-12">
 <div class="card-box table-responsive">

   <table class="table table-striped jambo_table bulk_action" style="width:100%">
   <thead>
      <tr>
      <th>NO</th>
      <th data-toggle="tooltip" data-placement="top" title="ISBN Harus Sesuai Dengan Buku, pakailah untuk searching">ISBN</th>
      <th data-toggle="tooltip" data-placement="top" title="Judul dan Sub Judul Dapat Dimasukkan disini">JUDUL BUKU</th>
      <th data-toggle="tooltip" data-placement="top" title="Nama Penulis Lengkap dan Sertakan Gelar">PENULIS</th>
      <th data-toggle="tooltip" data-placement="top" title="Penerbit Buku">PENERBIT</th>
      <th data-toggle="tooltip" data-placement="top" title="Jumlah Total Semua Buku dengan judul yang sama">JUMLAH</th>
      <th data-toggle="tooltip" data-placement="top" title="Lokasi tempat penyimpanan buku">LOKASI</th>
      <th data-toggle="tooltip" data-placement="top" title="Hasil Scan dan Upload File">BARCODE</th>
      <th data-toggle="tooltip" data-placement="top" title="Options berlaku sesuai dengan akses anda">OPTIONS</th>
      </tr>
    </thead>

<?php 

          $num_per_page = 5 ;
          $star_form = ($page-1)*$num_per_page;
          $query = "SELECT * FROM tbl_buku ORDER BY ID_BUKU DESC limit $star_form, $num_per_page";
           if(isset($_POST['search'])) {
            	 $search    = $_POST['search'];
                $query     = "SELECT * FROM  tbl_buku
            	              where ISBN like '%$search%'
            	             or JUDUL_BUKU like '%$search%' 
            	             or TAGS_BOOK like '%$search%'
            	             ";
                 
             
           }
       $no       = 1;
       $tampil   = mysqli_query($koneksi, $query);
 while($E_PERPUS = mysqli_fetch_array($tampil)) :
         
?>

    <tbody>
      <tr>
      <td><?=$no++?></td>
      <td><?=$E_PERPUS['ISBN']?></td>
      <td>
           <a href="?page=buku&hal=detail&dt=<?=$E_PERPUS['ID_BUKU']?>">
             <span class="fa fa-book"></span>
             <?=htmlspecialchars($E_PERPUS['JUDUL_BUKU'])?>
           </a>
      </td>
      <td><?=htmlspecialchars($E_PERPUS['PENGARANG'])?></td>
      <td><?=htmlspecialchars($E_PERPUS['PENERBIT'])?></td>
      <td><?=htmlspecialchars($E_PERPUS['JUMLAH_BUKU'])?></td>
      <td><?=htmlspecialchars($E_PERPUS['LOKASI'])?></td>
      <td>
           <img class="item" src="<?=$E_PERPUS['BARCODE']?>" alt="IMAGE BARCODE" width="100" height="100">
      </td>
      <td>
                        
                <div class="btn-group ">
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown"
                      aria-haspopup="true" aria-expanded="false">
                     Actions
                    </button>
                    <div class="dropdown-menu">
                      <a class="dropdown-item" href="?page=buku&hal=detail&dt=<?=$E_PERPUS['ID_BUKU']?>" name="detail_c" class="btn btn-success"data-toggle="modaal" data-target="#Detail_buuku">
                           DETAILS BOOK
                     </a>
                     <a class="dropdown-item" href="?page=buku&hal=update&id=<?=$E_PERPUS['ID_BUKU']?>" class="btn btn-warning" onclick="return confirm('Do you want to update ? \nBOOK : <?=$E_PERPUS['JUDUL_BUKU']?>')">
                      EDIT BOOK
                     </a>
                    
              <?php if($_SESSION['LEVEL'] == "ADMINISTRATOR"){ ?>
                     <a class="dropdown-item" href="?page=buku&hal=delete&id=<?=$E_PERPUS['ID_BUKU']?>" class="btn btn-danger" onclick="return confirm ('Do you want to remove ? \nBOOK : <?=$E_PERPUS['JUDUL_BUKU'];?>');" >
                       DELETE BOOK
                     </a>
              <? } ?>
                      
                    </div>
                  </div>

       
        
      </td>
      </tr>
      
<?php endwhile;?>

     
      </tbody>
     </table>
     <br>
     <center>
          
          Total Semua Buku : <?php $sql = mysqli_query($koneksi,"SELECT * FROM tbl_buku Order By ID_BUKU DESC");
            $total = mysqli_num_rows($sql); echo"$total"?>
     </center>
     <ul class="pagination">
       <?php
       
            $pr_query  = "SELECT * FROM tbl_buku Order By ID_BUKU DESC";
            $pr_result = mysqli_query($koneksi, $pr_query);
            $total_record = mysqli_num_rows($pr_result);
            $total_page = ceil($total_record/$num_per_page);
            $pg = 1 ;
            if ($page > 1) {
                 echo"<li class='page-item'>
                      <a href='?page=buku&pg=".($page-1)."' class='page-link'>Previous</a>
                      </li>";
            }
            for ($i = 1 ; $i <= $total_page; $i++) {?>
                 <li class="page-item ">
                  <a href="?page=buku&pg=<?=$i?>" class='page-link'><?=$i ?></a>
                  </li>
           <?php }
            if ($i > 2) {
                      echo"<li class='page-item'>
                      <a href='?page=buku&pg=".($page+1)."' class='page-link'>Next</a>
                      </li>";
            }
            
       ?>
      </ul>
<!-- Modal -->
     <div class="modal fade" id="New-Book" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">NEW BOOK</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a href="?page=buku&hal=create" class="btn btn-success">YES</a>
      </div>
    </div>
  </div>
</div>
<!-- end Modal Popup -->

    </div>
   </div>
  </div>
   </div>
     </div>
       </div>
         </div>
           </div>
        
<!-- end read content data buku  -->