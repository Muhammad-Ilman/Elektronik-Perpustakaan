<?php

     //Delete Buku Sesuai Id Buku
     if (isset($_GET['hal'])) {
           if ($_GET['hal'] == "delete") {
               $delete = mysqli_query($koneksi, "DELETE FROM tbl_users where ID_SISWA='$_GET[id]'");
               if ($delete) {
                    $confirm_delete = true;
               }
          }
     }
     if (isset($_GET['pg'])) {
             $page = $_GET['pg'];
      } else {
             $page = 1;
             
      }
?>

<!-- read content data buku -->
            <style>
                  .item:hover {
                  
                     
                      border-radius: 8px;
                      border: 0.5px solid ;
                      margin-top: 20px;
                      margin-bottom: 20px;
                      margin-right: 20px;
                      margin-left: 20px;
                      transition: 2.5s;
                      transform: scale(1.5);

                  }
              </style>
    <div class="right_col" role="main">
     <div class="">
      <div class="page-title">
       <div class="title_left">
        <h3></h3>
       </div>

        <div class="title_right">
         <div class="col-md-5 col-sm-5 form-group pull-right top_search">
           <div class="input-group">
            <input type="text" class="form-control" placeholder="Search for...">
              <span class="input-group-btn">
              <button class="btn btn-default" type="button">Go!</button>
              </span>
            </div>
         </div>
        </div>
       </div>

<div class="clearfix"></div>
  <div class="row">
    <div class="col-md-12 col-sm-12  ">
      <div class="x_panel">
       <div class="x_title">
         <h2></h2>
         <ul class="nav navbar-right panel_toolbox">
         <li><a class="collapse-link"><i class="fa fa-minus"></i></a></li>
         <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
         <li><a class="close-link"><i class="fa fa-close"></i></a></li>
         </ul>
                  
<div class="clearfix"></div></div>
  <div class="x_content">
       <?php
            if (isset($confirm_delete)) : ?>
                  <div class="alert alert-info">
                     <a data-dismiss="alert" style="float: right">
                        <i class="fa fa-close"></i>
                     </a>
                       <strong>Information !!</strong> Your User/Siswa Has Been Removed From The Electronic Perpustakaan
                   </div>
       <?php endif; ?>
    <form action="?page=users" method="post">
      <div class="input-group">
       <input type='search' class="form-control input-sm pull-right my-1 my-sm-1" style="width: 150px;"  name='search' placeholder="Search Here ...." autofocus="" onclick="document.getElementById('catatan').innerHTML='Cari Berdasarkan No Induk Siswa dan Nama Siswa'" autocomplete="off" required>

      
       <div class="input-group-btn">
        <button class="btn btn-info my-1 my-sm-1" name="submits" type="submit"><i class="fa fa-search"></i> Search</button>

        <a href="?page=users" class="btn btn-warning my-1 my-sm-1"><span class="fa fa-spinner fa-spin "></span> Refresh</a>
        <a href="?page=users&hal=create" class="btn btn-success my-1 my-sm-1"   data-toggle="modal" data-target="#Detail_buku"><span class="fa fa-user"></span> New User</a>
       </div>
      </div>
     <small id="catatan"></small>                 
    </form>    
<div class="col-sm-12">
 <div class="card-box table-responsive">

   <table class="table table-striped jambo_table bulk_action" style="width:100%">
   <thead>
      <tr>
         
      <th>No</th>
      <th>No Induk</th>
      <th>Jenis Kelamin</th>
      <th>Nama Lengkap</th>
      <th>Gambar</th>
      <th>Options</th>
         
      </tr>
    </thead>
                

<?php 

          $num_per_page = 5 ;
          $star_form = ($page-1)*$num_per_page;
          $query = "SELECT * FROM tbl_users ORDER BY ID_SISWA DESC limit $star_form, $num_per_page";
           if(isset($_POST['search'])) {
            	 $search    = $_POST['search'];
                $query     = "SELECT * FROM  tbl_users
            	              where NO_INDUK like '%$search%'
            	             or GENDER like '%$search%' 
            	             or NAMA_LENGKAP like '%$search%'
            	             ";
                 
             
           }
       $no       = 1;
       $tampil   = mysqli_query($koneksi, $query);
 while($E_PERPUS = mysqli_fetch_array($tampil)) :
         
?>

    <tbody>
      <tr>
      <td><?=$no++?></td>
      <td><?=$E_PERPUS['NO_INDUK']?></td>
      <td><?=$E_PERPUS['GENDER']?></td>
      <td>
           <a href=""  data-toggle="modal" data-target="#Detail_buku">
             <span class="fa fa-user"></span>
             <?php
             $aman= htmlspecialchars(
             $E_PERPUS['NAMA_LENGKAP']);
             printf($aman)
             
             ?>
           </a>
      </td>
      <td class="item">
         <center>
           <img class="item" src="MODUL/DATA_USERS/G_USERS/<?=$E_PERPUS['GAMBAR']?>" alt="IMAGE USER" width="100" height="100"></img></td>
         </center>
      <td>
                        
                <div class="btn-group ">
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown"
                      aria-haspopup="true" aria-expanded="false">
                     Actions
                    </button>
                    <div class="dropdown-menu">
                      <a class="dropdown-item" href="?page=buku&hal=detail&dt=<?=$E_PERPUS['ID_BUKU']?>" name="detail_c" class="btn btn-success"data-toggle="modaal" data-target="#Detail_buuku">
                           DETAILS BOOK
                     </a>
                     <a class="dropdown-item" href="?page=buku&hal=update&id=<?=$E_PERPUS['ID_BUKU']?>" class="btn btn-warning" onclick="return confirm('Apakah anda ingin Update buku baru'">
                      EDIT BOOK
                     </a>
                    
              <?php if($_SESSION['LEVEL'] == "ADMINISTRATOR"){ ?>
                     <a class="dropdown-item" href="?page=users&hal=delete&id=<?=$E_PERPUS['ID_SISWA']?>" class="btn btn-danger" onclick="return confirm ('Apakah anda yakin akan menghapus <?=$E_PERPUS['NAMA_LENGKAP'];?>.?');" >
                       DELETE BOOK
                     </a>
              <? } ?>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">PRINT BOOK</a>
                    </div>
                  </div>

       
        
      </td>
      </tr>
      
<?php endwhile;?>

     
      </tbody>
     </table>
     <br>
     <center>
          
          Total Semua Siswa : <?php $sql = mysqli_query($koneksi,"SELECT * FROM tbl_users Order By ID_SISWA DESC");
            $total = mysqli_num_rows($sql); echo"$total"?>
     </center>
     <ul class="pagination">
       <?php
       
            $pr_query  = "SELECT * FROM tbl_users Order By ID_SISWA DESC";
            $pr_result = mysqli_query($koneksi, $pr_query);
            $total_record = mysqli_num_rows($pr_result);
            $total_page = ceil($total_record/$num_per_page);
            $pg = 1 ;
            if ($page > 1) {
                 echo"<li class='page-item'>
                      <a href='?page=users&pg=".($page-1)."' class='page-link'>Previous</a>
                      </li>";
            }
            for ($i = 1 ; $i <= $total_page; $i++) {?>
                 <li class="page-item ">
                  <a href="?page=users&pg=<?=$i?>" class='page-link'><?=$i ?></a>
                  </li>
           <?php }
            if ($i > 2) {
                      echo"<li class='page-item'>
                      <a href='?page=users&pg=".($page+1)."' class='page-link'>Next</a>
                      </li>";
            }
            
       ?>
      </ul>
<!-- Modal Popup -->
     
<div class="modal fade" id="Detail_buku" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New USER</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

<p>
    Dengan Mengklik yes anda berarti menerima dan menyetujui syarat dan ketentuan aplikasi elektronik Perpustakaan
</p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
        <a href="?page=users&hal=create" type="button" class="btn btn-primary"> Yes</a>
      </div>
    </div>
  </div>
</div>

<!-- end Modal Popup -->

    </div>
   </div>
  </div>
   </div>
     </div>
       </div>
         </div>
           </div>
        
<!-- end read content data buku  -->