 <!-- page content -->
 <?php

  if (isset($_POST['send_users'])) {
       
        if ($_GET['hal'] == "update" ) {
            if (!empty($_FILES["GAMBAR"]["tmp_name"])) {
            	$JENIS=$_FILES['GAMBAR']['type'];
               	 if($JENIS=="image/jpeg"|| 
              	         $JENIS=="image/jpg" || 
               	    $JENIS=="image/gif" ||
               	    $JENIS=="image/png") {
              	       $E_FOLDER="MODUL/DATA_USERS/G_USERS/"; //Direktori tempat save file
                      $G_USERS = $E_FOLDER . basename($_FILES['GAMBAR']['name']);		
	                 $G_USER = $_FILES['GAMBAR']['name'];
	         	if (move_uploaded_file($_FILES['GAMBAR']['tmp_name'], $G_USERS)) {
	
				$update = mysqli_query($koneksi, "UPDATE `tbl_users` SET  NO_INDUK       ='$_POST[NO_INDUK]',
                              GENDER         ='$_POST[GENDER]',
                              TTL            ='$_POST[TTL]',
                              NAMA_LENGKAP   ='$_POST[NAMA_LENGKAP]',
                              ALAMAT         ='$_POST[ALAMAT]',
                              GAMBAR         ='$G_USER'
                              WHERE ID_SISWA ='$_GET[id]'
                              
               ");
            if ($update) {
                  echo "<script>
                      alert ('Identitas User hasbeen update please click yes/oke to continue...');
                      document.location='?page=users';
                        </script>";
            }
                  
	         	} else {
	                echo "<script>
                      alert ('Your Update Error');
                      document.location='Home?page=users&hal=create';
                        </script>";
                }
            } else {
              		echo "<script>
                      alert ('Gambar anda tidak memenuhi spesifikasi Harap masukkan jenis file .jpeg .jpg .gif');
                      document.location='Home?page=users&hal=create';
                        </script>";

                }
            } 
        }
    elseif ($_GET['hal'] == "create" ) {
            if (!empty($_FILES["GAMBAR"]["tmp_name"])) {
            	$JENIS=$_FILES['GAMBAR']['type'];
               	 if($JENIS=="image/jpeg"|| 
              	         $JENIS=="image/jpg" || 
               	    $JENIS=="image/gif" ||
               	    $JENIS=="image/png") {
              	       $E_FOLDER="MODUL/DATA_USERS/G_USERS/"; //Direktori tempat save file
                      $G_USERS = $E_FOLDER . basename($_FILES['GAMBAR']['name']);		
	                 $G_USER = $_FILES['GAMBAR']['name'];	
	   
	         	if (move_uploaded_file($_FILES['GAMBAR']['tmp_name'], $G_USERS)) {
		  //Autentikasi Dengan Database
               	   $NO_INDUK  = $_POST['NO_INDUK'];
                       $AUTH_ISBN = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tbl_users WHERE NO_INDUK='$NO_INDUK'"));
                   if ($AUTH_ISBN > 0) {
                        
                                  $confirm_pesan = true;
                              
                   } else {
               	
                        $query = mysqli_query($koneksi, "INSERT INTO `tbl_users` VALUES (
                              '',
                              '$NO_INDUK',
                              '$_POST[GENDER]',
                              '$_POST[TTL]',
                              '$_POST[NAMA_LENGKAP]',
                              '$_POST[ALAMAT]',
                              '$_POST[DIINPUT_OLEH]',
                              '$_POST[TANGGAL_INPUT]',
                              '$G_USER'
                              )");
                           
                              if ($query) {
                               echo "<script>
                                     alert ('Your user hasbeen create please click yes/oke to continue ..');
                                     document.location='?page=users&hal=create';
                                     </script>";
                              }
                           }
                  
	         	} else {
	                echo "<script>
                      alert ('ERROR');
                      document.location='Home?page=users&hal=create';
                        </script>";
                        return false;
                }
            } else {
              		echo "<script>
                      alert ('Gambar anda tidak memenuhi spesifikasi !! \nHarap masukkan jenis file .jpeg .jpg .gif');
                      document.location='Home?page=buku&hal=create';
                        </script>";

                }
            } 
        }
 }

      $tampil = mysqli_query($koneksi, "SELECT * from `tbl_users` WHERE ID_SISWA='$_GET[id]'");
        $E_PERPUS = mysqli_fetch_array($tampil);
             if ($E_PERPUS) {

                   $vno_induk     = $E_PERPUS['NO_INDUK'];
                   $vnama_lengkap = $E_PERPUS['NAMA_LENGKAP'];
                   $vTTL          = $E_PERPUS['TTL'];
                   $valamat       = $E_PERPUS['ALAMAT'];
                   $vfile         = $E_PERPUS['GAMBAR'];
               }
           
?>
 
 <div class="right_col" role="main">
   <div class="">
     <div class="page-title">
       <div class="title_left">
         <h3> </h3>
       </div>

       <div class="title_right">
        <div class="col-md-5 col-sm-5 form-group pull-right top_search">
          <div class="input-group">
              <input type="text" class="form-control" placeholder="Search for...">
              <span class="input-group-btn">
               <button class="btn btn-default" type="button">Go!</button>
              </span>
           </div>
         </div>
       </div>
     </div>

     <div class="clearfix"></div>

     <div class="row">
       <div class="col-md-8 col-sm-8 ">
         <div class="x_panel">
           <div class="x_title">
             <h2> FORM INPUT USER BARU</h2>
         <ul class="nav navbar-right panel_toolbox">

         </ul>
      <div class="clearfix"></div>
   </div>
 <div class="x_content"><br>
       <?php
            if (isset($confirm_pesan)) : ?>
                  <div class="alert alert-info">
                     <a data-dismiss="alert" style="float: right">
                        <i class="fa fa-close"></i>
                     </a>
                       <strong>Information !!</strong> User Already Exist, please check your No Induk
                   </div>
       <?php endif; ?>
<form action="" method="POST" enctype="multipart/form-data" class="form-horizontal form-label-left">
<div class="item form-group">
  	<label class="control-label col-md-3  " for="DIINPUT_OLEH"> DIDAFTARKAN OLEH <span class="required" >*</span>
  	</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="DIINPUT_OLEH" name="DIINPUT_OLEH" class="form-control "placeholder="" value="<?=$_SESSION['username']?>" readonly>

</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="TANGGAL_INPUT"> MENDAFTAR PADA <span class="required">*</span> 
		</label> 
<div class="col-md-7 col-sm-7">
		 <input type="text" id="TANGGAL_INPUT" name="TANGGAL_INPUT" required="required" class="form-control"  value="<?=date("l, d-m-y h:i:s");?>" readonly>
</div>
</div>
<br>
<div class="item form-group">
		<label class="control-label col-md-3" for="NO_INDUK"> NO INDUK<span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="number" id="NO_INDUK" name="NO_INDUK" required="required" class="form-control" placeholder="" value="<?=$vno_induk?>" onclick="document.getElementById('cinduk').innerHTML='Contoh : 19201628 (Masukkan Tanpa titik)'" autocomplete="off" data-toggle="tooltip" data-placement="right" title="This Value Is Required !">
		<small id="cinduk"></small>
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="NAMA_LENGKAP"> NAMA LENGKAP <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="NAMA_LENGKAP" name="NAMA_LENGKAP" required="required" class="form-control"value="<?=$vnama_lengkap?>" onclick="document.getElementById('cnama').innerHTML='Contoh :  M. Ilman Pratama Supardi Putra'" autocomplete="off" data-toggle="tooltip" data-placement="right" title="This Value Is Required !">
		<small id="cnama"></small>
		
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="TTL"> TEMPAT TANGGAL LAHIR <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="TTL" name="TTL" required="required" class="form-control" value="<?=$vTTL?>" onclick="document.getElementById('cTTL').innerHTML='Contoh :  Cianjur, 20 Agustus 2004'" autocomplete="off" data-toggle="tooltip" data-placement="right" title="This Value Is Required !">
		<small id="cTTL"></small>
		
</div>
</div>
<div class="item form-group">
	     <label class="control-label col-md-3">JENIS KELAMIN</label>
	    	<div class="col-md-6 col-sm-6 ">
	 	<div id="gender" class="btn-group" data-toggle="buttons">
	     	<label class="btn btn-dark" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default" data-toggle="tooltip" data-placement="bottom" title="Jenis Kelamin Laki-laki">
														<input type="radio" name="GENDER" value="Laki - Laki" class="join-btn" required=""> &nbsp; Laki-laki &nbsp;
													</label>
			<label class="btn btn-secondary" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default" data-toggle="tooltip" data-placement="bottom" title="Jenis Kelamin Perempuan ">
			     
                    <input type="radio" name="GENDER" value="perempuan" class="join-btn" required=""> perempuan
													</label>
		</div>
		</div>
</div>
<br>
<div class="item form-group">
		<label class="control-label col-md-3" for="PENERBIT"> ALAMAT RUMAH <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<textarea name="ALAMAT" id="ALAMAT" rows="4" class="form-control" onclick="document.getElementById('calamat').innerHTML='Contoh :  Jalan Cipadang Lampegan km 12 Desa Cibokor'" autocomplete="off" data-toggle="tooltip" data-placement="Right" title="This Value Is Required !"><?=$vfile?></textarea>
		<small id="calamat"></small>
		
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="GAMBAR"> GAMBAR SISWA <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="file" id="GAMBAR" name="GAMBAR" class="form-control" value="<?=$vfile?>" onchange="readFile();" required>
		<small>Catatan : Harap upload kembali file sebelum update</small>
</div>
</div>

<div class="item form-group ">
     <div class="container text-center">
       <input type="checkbox" class="my-2" id="sdk" required>
     <label class="" for="sdk"> I Have read and agree <a href=""><a href="" data-toggle="modal" data-target="#SDK"><strong>Terms and condition</strong></a> in Elektronik Perpustakaan application</label>
</div>
</div>
										
   <div class="ln_solid"></div>
   <div class="item form-group">
       <div class="col-md-7 col-sm-7 offset-md-3">
           <a href="?page=users" class="btn btn-dark" type="button" data-toggle="tooltip" data-placement="left" title="Back To Data"><i class="fa fa-arrow-circle-o-left"> </i> BACK </a>
            <a href="" class="btn btn-secondary" type="reset" data-toggle="tooltip" data-placement="top" title="Reset Your Form">RESET</a>
           <button type="submit" name="send_users" class="btn btn-success"data-toggle="tooltip" data-placement="right" title="Send New User">SEND</button>
                                    </div>
    </div>
</form>

  </div>
    </div>
      </div>
      
      


              <div class="col-md-4 col-sm-4">
             
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-user"></i> GAMBAR USER</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
                      <li><a class="close-link "><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <center>
                      <img src="" id="result" width="100%" height="auto" alt="&nbsp GAMBAR YANG ANDA UPLOAD &nbsp" style="border-radius :15px; border: 2px solid ">
                    </center>
                      <br>
                      <br>
                      <small>Preview Image User
                      
                      </small>
   

                     <script type="text/javascript">
                  function readFile() {
                     var reader = new FileReader();
                     var file = document.getElementById('GAMBAR').files[0];
               
                     reader.onload = function(e) {
                        document.getElementById('result').src = e.target.result;
                     }
               
                     reader.readAsDataURL(file);
                  }
               </script>


                  </div>
                </div>
            
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-image"></i>  GAMBAR USER SAAT INI</h2>
                    <ul class="nav navbar-right panel_toolbox">
                     &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <center>
                      <img src="MODUL/DATA_USERS/G_USERS/<?=$vfile?>" width="100%" height="auto" alt="&nbsp BERFUNGSI PADA SAAT UPDATE DATA USER &nbsp" style="border-radius :15px; border: 2px solid ">
                      </center>
                      <br>
                      <br>
                      <small><span class="fa fa-folder-open-o"></span> Direktori File : <a href="Direktori File : MODUL/DATA_USERS/G_USERS/<?=$vfile?>" target="_blank" data-toggle="tooltip" data-placement="top" title="Membuka Gambar Ditab Baru">
                      MODUL/DATA_USERS/G_USERS/<?=$vfile?>
                      </a>
                          
                      </small>
                     


                  </div>
                </div>
            
              </div>
       
              </div>
            </div>
  
      
        </div>
          </div>
            </div>
       
<!-- /page content -->

<!-- Modal Popup -->
     
<div class="modal fade" id="SDK" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New Book</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

<p>
    Dengan Mengklik yes anda berarti menerima dan menyetujui syarat dan ketentuan aplikasi elektronik Perpustakaan
</p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>

<!-- end Modal Popup -->
