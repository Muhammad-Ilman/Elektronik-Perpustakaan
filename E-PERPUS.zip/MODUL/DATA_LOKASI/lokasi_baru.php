<!-- page content -->
<?php
/*KETIKA TOMBOL SEND DITEKAN*/
if (isset($_POST['send'])) {
    if ($_GET['hal'] == "update") {
        $update = mysqli_query($koneksi, "UPDATE `tbl_lokasi` SET
          			NAMA_LOKASI        ='$_POST[NAMA_LOKASI]',
                         DESKRIPSI_OPSIONAL ='$_POST[DESKRIPSI_OPSIONAL]'
                         WHERE ID_LOKASI    ='$_GET[id]'
                         ");
                    if ($update) {
                          echo "<script>
                                  alert ('Book hasbeen update please click yes/oke to continue...');
                                        document.location='?page=lokasi';
                                </script>";
                                     }


    } elseif ($_GET['hal'] == "create") {

        /*CEK DATA KE DATABASE*/
        $NAMA_LOKASI = $_POST['NAMA_LOKASI'];
        $AUTH_LOC = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tbl_lokasi WHERE NAMA_LOKASI='$NAMA_LOKASI'"));
        if ($AUTH_LOC > 0) {
            $auth_nama = true;

            /*END CEK DATA*/
        } else {

            $create = mysqli_query($koneksi, "INSERT INTO `tbl_lokasi` VALUES (
               '',
               '$_POST[KODE_LOKASI]',
               '$_POST[TANGGAL_INPUT]',
               '$_POST[DIINPUT_OLEH]',
               '$NAMA_LOKASI',
               '$_POST[DESKRIPSI_OPSIONAL]'
               )");
          
               if ($create) {
                echo "<script>
                      alert ('Location hasbeen create please click yes/oke to continue ..');
                      document.location='?page=lokasi';
                      </script>";
               }
        }
    }
}
/*END TOMBOL SEND*/



/*KODE OTOMATIS*/
$sql = "SELECT max(ID_LOKASI) as max_id FROM tbl_lokasi WHERE ID_LOKASI ORDER BY ID_LOKASI DESC LIMIT 1";
$query1 = mysqli_query($koneksi, $sql);
$E_PERPUS = mysqli_fetch_assoc($query1);
$getid = $E_PERPUS['max_id'];
$no = substr($getid, -5, 5);
$no = (int) $no;
$no = $no + 1;
$nid = sprintf("%05s", $no);
/*END KODE OTOMATIS*/

/*MENAMPILKAN DATA YANG AKAN DI-UPDATE*/
$tampil = mysqli_query($koneksi, "SELECT * from `tbl_lokasi` WHERE ID_LOKASI='$_GET[id]'");
$E_PERPUS = mysqli_fetch_array($tampil);
if ($E_PERPUS) {
    $vnama_lokasi = $E_PERPUS['NAMA_LOKASI'];
    $vdesop = $E_PERPUS['DESKRIPSI_OPSIONAL'];

}

?>

<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3> </h3>
            </div>

            <div class="title_right">
                <div class="col-md-5 col-sm-5 form-group pull-right top_search">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                            <button class="btn btn-default" type="button">Go!</button>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                    <div class="x_title">
                        <h2><span class="fa fa-tag"></span> FORM INPUT LOKASI BARU</h2>
                        <ul class="nav navbar-right panel_toolbox">

                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        

                        
                           <?php
                                if (isset($auth_nama)) : ?>
                                      <div class="alert alert-info">
                                         <a data-dismiss="alert" style="float: right">
                                            <i class="fa fa-close"></i>
                                         </a>
                                           <strong>Information !!</strong> Location Already Exist, please check your location name
                                       </div>
                           <?php endif; ?>
                        

                        <form action="" method="POST" enctype="multipart/form-data" class="form-horizontal form-label-left">
                            <div class="item form-group">
                                <label class="control-label col-md-3  " for="KODE_LOKASI"> KODE LOKASI <span class="required">*</span>
                                </label>
                                <div class="col-md-7 col-sm-7">
                                    <input type="text" id="KODE_LOKASI" name="KODE_LOKASI" class="form-control "placeholder="" value="E-PERPUS/L-RK/<?=date("yy.").$nid; ?>" readonly>

                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3" for="TANGGAL_INPUT"> TANGGAL INPUT <span class="required">*</span>
                                </label>
                                <div class="col-md-7 col-sm-7">
                                    <input type="text" id="TANGGAL_INPUT" name="TANGGAL_INPUT" required="required" class="form-control" value="<?=date("l, d-m-y h:i:s"); ?>" readonly>
                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="control-label col-md-3" for="DIINPUT_OLEH"> DIINPUT OLEH <span class="required">*</span>
                                </label>
                                <div class="col-md-7 col-sm-7">
                                    <input type="text" id="DIINPUT_OLEH" name="DIINPUT_OLEH" required="required" class="form-control"value="<?=$_SESSION['username'] ?>" readonly="" autocomplete="off">

                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="control-label col-md-3" for="NAMA_LOKASI"> NAMA LOKASI <span class="required">*</span>
                                </label>
                                <div class="col-md-7 col-sm-7">
                                    <input type="text" id="NAMA_LOKASI" name="NAMA_LOKASI" required="required" class="form-control"value="<?=$vnama_lokasi ?>" autocomplete="off" onclick="document.getElementById('cname').innerHTML='Contoh :  Rak - 001'" data-toggle="tooltip" data-placement="right" title="This Value is Required !">

                                    <small id="cname"></small>

                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="control-label col-md-3" for="DESKRIPSI_OPSIONAL"> DESKRIPSI OPSIONAL <span class="required">*</span>
                                </label>
                                <div class="col-md-7 col-sm-7">
                                    <textarea name="DESKRIPSI_OPSIONAL" id="DESKRIPSI_OPSIONAL" rows="4" class="form-control" onclick="document.getElementById('cdesof').innerHTML='Contoh :  Berdekatan dengan Rak - 14'" autocomplete="off"data-toggle="tooltip" data-placement="right" title="This Value is Required !"><?=$vdesop ?></textarea>
                                    <small id="cdesof"></small>
                                </div>
                            </div>


                            <br>
                            <div class="item form-group ">
                                <div class="container text-center">
                                    <input type="checkbox" class="my-2" id="sdk" required>
                                    <label class="" for="sdk"> I Have read and agree <a href=""><a href="" data-toggle="modal" data-target="#SDK"><strong>Terms and condition</strong></a> in Elektronik Perpustakaan application</label>
                                    </div>
                                </div>

                                <div class="ln_solid"></div>
                                      <div class="item form-group">
                                          <div class="col-md-7 col-sm-7 offset-md-3">
                                              <a href="?page=lokasi" class="btn btn-dark" type="button" data-toggle="tooltip" data-placement="left" title="Back To Data"><i class="fa fa-arrow-circle-o-left"> </i> BACK </a>
                                               <a href="" class="btn btn-secondary" type="reset" data-toggle="tooltip" data-placement="top" title="Reset Your Form">RESET</a>
                                              <button type="submit" name="send" class="btn btn-success"data-toggle="tooltip" data-placement="right" title="Send New Location">SEND</button>
                                           </div>
                                       </div>
                                                               </form>

                        </div>
                    </div>
                </div>


            </div>
        </div>


    </div>
</div>
</div>

<!-- /page content -->

<!-- Modal Popup -->

<div class="modal fade" id="SDK" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLabel">SYARAT DAN KETENTUAN</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">

<p>
Dengan Mengklik yes anda berarti menerima dan menyetujui syarat dan ketentuan aplikasi elektronik Perpustakaan
</p>

</div>
<div class="modal-footer">
<button type="button" class="btn btn-success" data-dismiss="modal">Close</button>

</div>
</div>
</div>
</div>

<!-- end Modal Popup -->