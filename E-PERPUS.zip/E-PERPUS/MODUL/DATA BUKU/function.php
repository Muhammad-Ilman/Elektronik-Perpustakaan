<?php
    //function searching on database
  function cari($search) {
      $search = $_POST['search'];
     $query = "SELECT * FROM  tbl_buku
  	               where ID_BUKU like '%$search%'
  	               or ISBN like '%$search%'";
     
  }


?>