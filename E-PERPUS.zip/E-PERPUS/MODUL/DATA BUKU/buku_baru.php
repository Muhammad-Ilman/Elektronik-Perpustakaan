 <!-- page content -->
 <?php

  if (isset($_POST['send_book'])) {
        if ($_GET['hal'] == "update" ) {
            if (!empty($_FILES["BARCODE"]["tmp_name"])) {
            	$JENIS=$_FILES['BARCODE']['type'];
               	 if($JENIS=="image/jpeg"|| 
              	    $JENIS=="image/jpg" || 
               	    $JENIS=="image/gif" ||
               	    $JENIS=="image/png") {
              	     $E_FOLDER="ASSETS/FILE/"; //tempat save file
                      $G_BARCODE = $E_FOLDER . basename($_FILES['BARCODE']['name']);		
	   
	         	if (move_uploaded_file($_FILES['BARCODE']['tmp_name'], $G_BARCODE)) {
		  
   
	
				$update = mysqli_query($koneksi, "UPDATE `tbl_buku` SET  JUDUL_BUKU='$_POST[JUDUL_BUKU]',
               ISBN='$_POST[ISBN]',
               PENGARANG='$_POST[PENGARANG]',
               PENELAAH='$_POST[PENELAAH]',
               PENERBIT='$_POST[PENERBIT]',
               TAHUN_TERBIT='$_POST[TAHUN_TERBIT]',
               EDISI='$_POST[EDISI]',
               KATEGORI='$_POST[KATEGORI]',
               TANGGAL_INPUT='$_POST[TANGGAL_INPUT]',
               CARA_PENGADAAN='$_POST[CARA_PENGADAAN]',
               HARGA='$_POST[HARGA_BUKU]',
               LOKASI='$_POST[LOKASI_BUKU]',
               JUMLAH_BUKU='$_POST[JUMLAH_BUKU]',
               BARCODE='$G_BARCODE',
               DESKRIPSI_FISIK='$_POST[DESKRIPSI_FISIK]',
               DESKRIPSI_OPSIONAL='$_POST[DESKRIPSI_OPSIONAL]',
               TAGS_BOOK='$_POST[TAGS_BOOK]'
               
               WHERE ID_BUKU='$_GET[id]'
               
               ");
            if ($update) {
                  echo "<script>
                      alert ('Buku Telah Behasil Di-update');
                      document.location='?page=buku&hal=read';
                        </script>";
            }
                  
	         	} else {
	                echo "<script>
                      alert ('Gambar Gagal UPDT ke direktori FILE Berikut dengan Bukunya');
                      document.location='Home?page=buku&hal=create';
                        </script>";
                }
            } else {
              		echo "<script>
                      alert ('Gambar anda tidak memenuhi spesifikasi Harap masukkan jenis file .jpeg .jpg .gif');
                      document.location='Home?page=buku&hal=create';
                        </script>";

                }
            } 
        }
   elseif ($_GET['hal'] == "create" ) {
            if (!empty($_FILES["BARCODE"]["tmp_name"])) {
            	$JENIS=$_FILES['BARCODE']['type'];
               	 if($JENIS=="image/jpeg"|| 
              	    $JENIS=="image/jpg" || 
               	    $JENIS=="image/gif" ||
               	    $JENIS=="image/png") {
              	     $E_FOLDER="ASSETS/FILE/"; //tempat save file
                      $G_BARCODE = $E_FOLDER . basename($_FILES['BARCODE']['name']);		
	   
	         	if (move_uploaded_file($_FILES['BARCODE']['tmp_name'], $G_BARCODE)) {
		  
	    	$ISBN = $_POST['ISBN'];
        $AUTH_ISBN = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tbl_buku WHERE ISBN='$_POST[ISBN]'"));
    if ($AUTH_ISBN > 0) {
                          echo "<script>
                        alert ('MAAF BUKU DENGAN ISBN TERSEBUT SUDAH ADA');
                    document.location='Home?page=buku&hal=create';
                    </script>";
    } else {
	
				$query = mysqli_query($koneksi, "INSERT INTO `tbl_buku` VALUES (
               '',
               '$_POST[KODE_BUKU]',
               '$_POST[JUDUL_BUKU]',
               '$ISBN',
               '$_POST[PENGARANG]',
               '$_POST[PENELAAH]',
               '$_POST[PENERBIT]',
               '$_POST[TAHUN_TERBIT]',
               '$_POST[EDISI]',
               '$_POST[KATEGORI]',
               '$_POST[TANGGAL_INPUT]',
               '$_POST[CARA_PENGADAAN]',
               '$_POST[HARGA_BUKU]',
               '$_POST[LOKASI_BUKU]',
               '$_POST[JUMLAH_BUKU]',
               '$G_BARCODE',
               '$_POST[DESKRIPSI_FISIK]',
               '$_POST[DESKRIPSI_OPSIONAL]',
               '$_POST[TAGS_BOOK]'
               )");
               if ($query) {
                echo "<script>
                      alert ('Gambar Telah Terkirim ke direktori File Berikut dengan Bukunya');
                      document.location='?page=buku&hal=read';
                      </script>";
               }
            }
                  
	         	} else {
	                echo "<script>
                      alert ('Gambar Gagal Terkirim ke direktori FILE Berikut dengan Bukunya');
                      document.location='Home?page=buku&hal=create';
                        </script>";
                }
            } else {
              		echo "<script>
                      alert ('Gambar anda tidak memenuhi spesifikasi Harap masukkan jenis file .jpeg .jpg .gif');
                      document.location='Home?page=buku&hal=create';
                        </script>";

                }
            } 
        }
 }
 
 $sql = "SELECT max(ID_BUKU) as max_id FROM tbl_buku WHERE ID_BUKU ORDER BY ID_BUKU DESC LIMIT 1";
 $query1 = mysqli_query($koneksi, $sql);
 $E_PERPUS = mysqli_fetch_assoc($query1);
 $getid = $E_PERPUS['max_id'];
 $no = substr($getid, -5, 5);
 $no = (int) $no;
 $no = $no + 1;
 $nid = sprintf("%05s", $no);
 
      $tampil = mysqli_query($koneksi, "SELECT * from `tbl_buku` WHERE ID_BUKU='$_GET[id]'");
        $E_PERPUS = mysqli_fetch_array($tampil);
             if ($E_PERPUS) {
                   $visbn         = $E_PERPUS['ISBN'];
                   $vjudul_buku   = $E_PERPUS['JUDUL_BUKU'];
                   $vpengarang    = $E_PERPUS['PENGARANG'];
                   $vpenerbit     = $E_PERPUS['PENERBIT'];
                   $vpenelaah     = $E_PERPUS['PENELAAH'];
                   $vedisi        = $E_PERPUS['EDISI'];
                   $vtahun_terbit = $E_PERPUS['TAHUN_TERBIT'];
                   $vharga        = $E_PERPUS['HARGA'];
                   $vjumlah_buku  = $E_PERPUS['JUMLAH_BUKU'];
                   $vjumlah_buku  = $E_PERPUS['JUMLAH_BUKU'];
                   $vsumber       = $E_PERPUS['CARA_PENGADAAN'];
                   $vlokasi       = $E_PERPUS['LOKASI'];
                   $vkategori     = $E_PERPUS['KATEGORI'];
                   $vtags         = $E_PERPUS['TAGS_BOOK'];
                   $vdesfis       = $E_PERPUS['DESKRIPSI_FISIK'];
                   $vdesop        = $E_PERPUS['DESKRIPSI_OPSIONAL'];
                   $vfile         = $E_PERPUS['BARCODE'];
               }
           
?>
 
 <div class="right_col" role="main">
   <div class="">
     <div class="page-title">
       <div class="title_left">
         <h3> </h3>
       </div>

       <div class="title_right">
        <div class="col-md-5 col-sm-5 form-group pull-right top_search">
          <div class="input-group">
              <input type="text" class="form-control" placeholder="Search for...">
              <span class="input-group-btn">
               <button class="btn btn-default" type="button">Go!</button>
              </span>
           </div>
         </div>
       </div>
     </div>

     <div class="clearfix"></div>

     <div class="row">
              <div class="col-md-12 col-sm-12 ">
         <div class="x_panel">
           <div class="x_title">
             <h2><span class="fa fa-edit"></span> Form Input Buku Baru</h2>
         <ul class="nav navbar-right panel_toolbox">

         </ul>
      <div class="clearfix"></div>
   </div>
 <div class="x_content"><br>

<form action="" method="POST" enctype="multipart/form-data" class="form-horizontal form-label-left">
<div class="item form-group">
  	<label class="control-label col-md-3  " for="KODE_BUKU">KODE BUKU <span class="required" >*</span>
  	</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="KODE_BUKU" name="KODE_BUKU" class="form-control "placeholder="" value="E-PERPUS/BUKU/<?=date("yymd.").$nid;?>" readonly>

</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="TANGGAL_INPUT"> TANGGAL INPUT <span class="required">*</span> 
		</label> 
<div class="col-md-7 col-sm-7">
		 <input type="text" id="TANGGAL_INPUT" name="TANGGAL_INPUT" required="required" class="form-control"  value="<?=date("l, d-m-y h:i:s");?>" readonly>
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="ISBN"> ISBN BUKU <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="number" id="ISBN" name="ISBN" required="required" class="form-control" placeholder="" value="<?=$visbn?>" onclick="document.getElementById('cisbn').innerHTML='Contoh : 9789797943059'" autocomplete="off">
		<small id="cisbn"></small>
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="JUDUL_BUKU"> JUDUL BUKU <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="JUDUL_BUKU" name="JUDUL_BUKU" required="required" class="form-control"value="<?=$vjudul_buku?>" onclick="document.getElementById('cjudul').innerHTML='Contoh :  Website Super Keren dengan Wordpress 3.x'" autocomplete="off">
		<small id="cjudul"></small>
		
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="PENGARANG"> PENGARANG <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="PENGARANG" name="PENGARANG" required="required" class="form-control" value="<?=$vpengarang?>" onclick="document.getElementById('cpengarang').innerHTML='Contoh :  Ali Zainal'" autocomplete="off">
		<small id="cpengarang"></small>
		
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="PENERBIT"> PENERBIT <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="PENERBIT" name="PENERBIT" required="required" class="form-control" value="<?=$vpenerbit?>" onclick="document.getElementById('cpenerbit').innerHTML='Contoh :  Media Kita'" autocomplete="off">
		<small id="cpenerbit"></small>
		
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="PENELAAH"> PENELAAH <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="PENELAAH" name="PENELAAH" required="required" class="form-control"  value="<?=$vpenelaah?>" onclick="document.getElementById('cpenelaah').innerHTML='Contoh :  Budi Setiawan, Indah Lestari, Eko Haryanto'" autocomplete="off">
		<small id="cpenelaah"></small>
		
</div>
</div>
<br>
<div class="ln_solid"></div>
<br>
<div class="item form-group">
		<label class="control-label col-md-3" for="EDISI"> CETAKAN / EDISI <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="EDISI" name="EDISI" required="required" class="form-control" value="<?=$vedisi?>" onclick="document.getElementById('cedisi').innerHTML='Contoh :  Cetakan Pertama / Best Seller'" autocomplete="off">
		<small id="cedisi"></small>
		
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="TAHUN_TERBIT"> TAHUN TERBIT <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
    		<select class="form-control"id="TAHUN_TERBIT" name="TAHUN_TERBIT" onclick="document.getElementById('cterbit').innerHTML='Contoh : 2011'" autocomplete="off" required>
		
		<option value="<?=@$vtahun_terbit?>"><?=$vtahun_terbit?></option>
		<option value="2000">2000</option>
		<option value="2000">2001</option>
		<option value="2000">2002</option>
		<option value="2000">2003</option>
		<option value="2000">2004</option>
		<option value="2000">2005</option>
		<option value="2000">2006</option>
		<option value="2000">2007</option>
		<option value="2000">2008</option>
		<option value="2000">2009</option>
		<option value="2000">2010</option>
		<option value="2000">2011</option>
		<option value="2000">2012</option>
		<option value="2000">2013</option>
		<option value="2000">2014</option>
		<option value="2000">2015</option>
		<option value="2000">2016</option>
		<option value="2000">2017</option>
		<option value="2000">2018</option>
		<option value="2000">2019</option>
		<option value="2000">2020</option>

    		</select>
    		
		<small id="cterbit"></small>
</div>
</div>


<div class="item form-group">
		<label class="control-label col-md-3" for="HARGA_BUKU"> HARGA BUKU <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="HARGA_BUKU" name="HARGA_BUKU" required="required" class="form-control" value="<?=$vharga?>" onclick="document.getElementById('charga').innerHTML='Contoh :  35000'" autocomplete="off">
		<small id="charga"></small>
		
</div>

</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="JUMLAH_BUKU"> JUMLAH BUKU <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="number" id="JUMLAH_BUKU" name="JUMLAH_BUKU" required="required" class="form-control" value="<?=$vjumlah_buku?>" onclick="document.getElementById('cjumlah').innerHTML='Contoh : 01'" autocomplete="off">
		<small id="cjumlah"></small>
		
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="CARA_PENGADAAN"> CARA PENGADAAN <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<select class="form-control"id="CARA_PENGADAAN" name="CARA_PENGADAAN" onclick="document.getElementById('csumber').innerHTML='Contoh :  Pembelian'" autocomplete="off" required>
		>
    <!--   <option value="">PILIH SUMBER PENGADAAN</option>-->
       <option><?=@$vsumber?></option>
          <?php
                         
          $tampil = mysqli_query($koneksi,"SELECT * from `tbl_pengadaan` order by NAMA_PENGADAAN asc");
     while($E_PERPUS = mysqli_fetch_array($tampil)) {
           echo "<option value= '$E_PERPUS[NAMA_PENGADAAN]'> $E_PERPUS[NAMA_PENGADAAN]</option>";
            }
                         
                         ?>
                    </select>
		<small id="csumber"></small>
</div>

</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="LOKASI_BUKU"> LOKASI BUKU <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
			<select class="form-control"id="LOKASI_BUKU" name="LOKASI_BUKU" onclick="document.getElementById('clokasi').innerHTML='Contoh :  RAK - 001'" autocomplete="off">
		
			 <option><?=$vlokasi?></option>
       
          <?php
                         
          $tampil = mysqli_query($koneksi,"SELECT * from `tbl_lokasi` order by NAMA_LOKASI asc");
     while($E_PERPUS = mysqli_fetch_array($tampil)) {
           echo "<option value= '$E_PERPUS[NAMA_LOKASI]'> $E_PERPUS[NAMA_LOKASI]</option>";
            }
                         
                         ?>
                    </select>
		<small id="clokasi"></small>
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="KATEGORI"> KATEGORI <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">

		 <select class="form-control"id="KATEGORI" name="KATEGORI" onclick="document.getElementById('ckategori').innerHTML='Contoh : Buku Bacaan, Non fiksi'" autocomplete="off" required>
		
		   <option><?=$vkategori?></option>
    
          <?php
                         
          $tampil = mysqli_query($koneksi,"SELECT * from `tbl_kategori` order by NAMA_KATEGORI asc");
     while($E_PERPUS = mysqli_fetch_array($tampil)) {
           echo "<option value= '$E_PERPUS[NAMA_KATEGORI]'> $E_PERPUS[NAMA_KATEGORI]</option>";
            }
                         
                         ?>
                    </select>
		<small id="ckategori"></small>
</div>
</div>
  


<div class="item form-group">
		<label class="control-label col-md-3" for="BARCODE"> BARCODE <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="file" id="BARCODE" name="BARCODE" class="form-control" value="<?=$vfile?>" onchange="readFile();" required>
		<small>Catatan : Harap upload kembali file sebelum update</small>
</div>
</div>
<!--
<div class="item form-group">
		<label class="control-label col-md-3" for="BARCODE_ISBN"> BARCODE ISBN <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="file" id="BARCODE_ISBN" name="BARCODE_ISBN" class="form-control">
</div>
</div>-->

<br>
<br>
<div class="ln_solid"></div>
<div class="item form-group">
		<label class="control-label col-md-3" for="DESKRIPSI_FISIK"> DESKRIPSI FISIK <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<textarea id="DESKRIPSI_FISIK" name="DESKRIPSI_FISIK" required="required" class="form-control" onclick="document.getElementById('cdesfis').innerHTML='Contoh : iv - 138 hlm ; ilus ; 15cm × 23cm'" autocomplete="off"><?=$vdesfis?></textarea>
		<small id="cdesfis"></small>
</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="DESKRIPSI_OPSIONAL"> DESKRIPSI OPSIONAL <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<textarea id="DESKRIPSI_OPSIONAL" name="DESKRIPSI_OPSIONAL" required="required" class="form-control" onclick="document.getElementById('cdesof').innerHTML='Contoh :  Belajar Membuat Website dengan Wordpress 3.x'" autocomplete="off"><?=$vdesop?>
		</textarea>
		<small id="cdesof"></small>
</div>
</div>
<div class="item form-group ">
	<label class="control-label col-md-3 col-sm-3 ">TAGS BOOK</label>
		<div class="col-md-7 col-sm-7">
			<input id="tags_1" type="text" name="TAGS_BOOK" class="tags form-control" value="<?=$vtags?>" autocomplete="off">
		<small class="col-sm-6 col-md-7">Contoh : Website, Pramuka, Olahraga</small>
		
				<div id="suggestions-container" style="position: relative; float: left; width: 250px; margin: 10px;"></div>
											</div>
										</div>
										
<br>
<div class="item form-group ">
     <div class="container text-center">
       <input type="checkbox" class="my-2" id="sdk" required>
     <label class="" for="sdk"> I Have read and agree <a href=""><a href="" data-toggle="modal" data-target="#SDK"><strong>Terms and condition</strong></a> in Elektronik Perpustakaan application</label>
</div>
</div>
										
<div class="ln_solid"></div>
     <div class="item form-group">
          <div class="col-md-7 col-sm-7 offset-md-3">
		     <a href="?page=buku&hal=read" class="btn btn-primary" type="button"><i class="fa fa-arrow-circle-o-left"> </i> CANCEL</a>
		     <a href="" class="btn btn-danger" type="reset">RESET</a>
		     <button type="submit" name="send_book" class="btn btn-success"><span class="fa fa-send"></span> SEND BOOK</button>
		</div>
	</div>
</form>

  </div>
    </div>
      </div>
      
          
              <div class="col-md-6  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-barcode"></i> File Barcode</h2>
                    <ul class="nav navbar-right panel_toolbox">
                     &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <center>
                      <img src="<?=$vfile?>" width="100%" height="auto" alt="&nbsp FILE BERFUNGSI PADA SAAT UPDATE BUKU &nbsp" style="border-radius :15px; border: 2px solid ">
                      </center>
                      <br>
                      <br>
                      <small>
                      Direktori File : <?=$vfile?>
                          
                      </small>
                     


                  </div>
                </div>
              </div>
           
           
              <div class="col-md-6 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-upload"></i> Preview Barcode Upload</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
                      <li><a class="close-link "><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <center>
                      <img src="" id="result" width="100%" height="auto" alt="&nbsp FILE BARCODE YANG ANDA UPLOAD &nbsp" style="border-radius :15px; border: 2px solid ">
                    </center>
                      <br>
                      <br>
                      <small>Preview Barcode Book
                      
                      </small>
   

                     <script type="text/javascript">
                  function readFile() {
                     var reader = new FileReader();
                     var file = document.getElementById('BARCODE').files[0];
               
                     reader.onload = function(e) {
                        document.getElementById('result').src = e.target.result;
                     }
               
                     reader.readAsDataURL(file);
                  }
               </script>


                  </div>
                </div>
              </div>
          
      

              </div>
            </div>
  
      
        </div>
          </div>
            </div>
       
<!-- /page content -->

<!-- Modal Popup 
     
<div class="modal fade" id="SDK" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New Book</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

<p>
    Dengan Mengklik yes anda berarti menerima dan menyetujui syarat dan ketentuan aplikasi elektronik Perpustakaan
</p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>

<!-- end Modal Popup -->
