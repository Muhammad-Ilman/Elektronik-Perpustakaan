<!-- Elektronik Perpustakaan Detail content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>
<?php

    $query="select * from tbl_buku WHERE ID_BUKU='$_GET[dt]'";
    $tampil = mysqli_query($koneksi, $query);
    $E_PERPUS   = mysqli_fetch_array($tampil);
    
        $ID_BUKU         = $E_PERPUS['ID_BUKU'];
        $KODE_BUKU       = $E_PERPUS['KODE_BUKU'];
        $JUDUL_BUKU      = $E_PERPUS['JUDUL_BUKU'];
        $ISBN            = $E_PERPUS['ISBN'];
        $PENULIS         = $E_PERPUS['PENGARANG'];
        $PENELAAH        = $E_PERPUS['PENELAAH'];
        $PENERBIT        = $E_PERPUS['PENERBIT'];
        $TAHUN_TERBIT    = $E_PERPUS['TAHUN_TERBIT'];
        $EDISI           = $E_PERPUS['EDISI'];
        $KATEGORI        = $E_PERPUS['KATEGORI'];
        $TANGGAL_INPUT   = $E_PERPUS['TANGGAL_INPUT'];
        $CARA_PENGADAAN  = $E_PERPUS['CARA_PENGADAAN'];
        $HARGA           = $E_PERPUS['HARGA'];
        $LOKASI          = $E_PERPUS['LOKASI'];
        $JUMLAH_BUKU     = $E_PERPUS['JUMLAH_BUKU'];
        $BARCODE         = $E_PERPUS['BARCODE'];
        $DESFIS          = $E_PERPUS['DESKRIPSI_FISIK'];
        $DESOPS          = $E_PERPUS['DESKRIPSI_OPSIONAL'];
        $TAGS_BOOK       = $E_PERPUS['TAGS_BOOK'];
?>
            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><i class="fa fa-tags"></i> Detail Buku <?=$JUDUL_BUKU?></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-minus-square-o"></i></a>
                      </li>
                      <li><a class="collapse-link"><i class="fa fa-back"></i></a>
                      </li>
 
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                     <div class="card-box table-responsive">
                  <table id="example" class="table table-hover table-bordered">
                    <tr>
                    <td>ID BUKU</td>
                    <td><?=$ID_BUKU?></td>
                    <td rowspan="6"><center>ISBN BARCODE - QR
                       <img src="<?=$BARCODE?>" height="230" width="270" alt="<?=$ISBN?>"/>
                            <?=$ISBN?>
                        </center></td>
                    </tr>

                    <tr>
                    <td width="200">KODE BUKU</td>
                    <td width="500"><?=$KODE_BUKU?></td>
                    </tr>
                    <tr>
                    <td>ISBN NO</td>
                    <td><?=$ISBN?></td>
                    </tr>
                    
                    <tr>
                    <td>TANGGAL INPUT</td>
                    <td><?=$TANGGAL_INPUT?></td>
                    </tr>
                    
                    <tr>
                    <td>JUDUL BUKU</td>
                    <td><?=$JUDUL_BUKU?></td>
                    </tr>
                    
                    <tr>
                    <td>PENULIS</td>
                    <td><?=$PENULIS?></td>
                    </tr>
                    
                    <tr>
                    <td>PENERBIT</td>
                    <td colspan="2"><?=$PENERBIT?></td>
                    </tr>
                    
                    <tr>
                    <td>PENELAAH</td>
                    <td colspan="2"><?=$PENELAAH?></td>
                    </tr>
                    
                    <tr>
                    <td>EDISI</td>
                    <td colspan="2"><?=$EDISI?></td>
                    </tr>
                    
                    <tr>
                    <td>TAHUN TERBIT</td>
                    <td colspan="2"><?=$TAHUN_TERBIT?></td>
                    </tr>
                    
                    
                    <tr>
                    <td>JUMLAH BUKU</td>
                    <td colspan="2"><?=$JUMLAH_BUKU ?></td>
                    </tr>
                   
                   
                    <tr>
                    <td>LOKASI</td>
                    <td colspan="2"><?=$LOKASI?></td>
                    </tr>
                    
                    <tr>
                    <td>HARGA</td>
                    <td colspan="2"><?=$HARGA?></td>
                    </tr> 
                    
                    <tr>
                    <td>CARA PENGADAAN</td>
                    <td colspan="2"><?=$CARA_PENGADAAN?></td>
                    </tr>
                    
                    <tr>
                    <td>KATEGORI</td>
                    <td colspan="2"><?=$KATEGORI?></td>
                    </tr>
                    
                    <tr>
                    <td>DESKRIPSI FISIK</td>
                    <td colspan="2"><?=$DESFIS?></td>
                    </tr>
                    
                    <tr>
                    <td>DESKRIPSI OPSIONAL</td>
                    <td colspan="2"><?=$DESOPS?></td>
                    </tr>
                    
                    <tr>
                    <td>TAGS BOOK</td>
                    <td colspan="2"><?=$TAGS_BOOK?></td>
                    </tr>
                    
                    
                    
                    

                   </table>
                    </div>
      <div class="ln_solid"></div>             
        <a href="PRINT/cetak_detail_buku.php?printid=<?=$ID_BUKU?>" class="btn btn-primary" style="float: right" l><i class="fa fa-print"></i></a>
                   
        <a class="btn btn-success" href="https://api.whatsapp.com/send?text=
         📚 *<?=$JUDUL_BUKU?>*
            <?php echo"*ISBN* : $ISBN"?>
            <?php echo"*PENULIS* : $PENULIS"?> | 
            <?php echo"*PENERBIT* : $PENERBIT"?> | 
            <?php echo"*TAHUN TERBIT* : $TAHUN_TERBIT"?>
            
            " target="_blank" style="float: right">
         <i class="fa fa-whatsapp"></i> WhatsApp</a>


                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      
<!-- E - PERPUS end content -->