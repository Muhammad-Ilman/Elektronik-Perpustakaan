 <!-- page content -->
 <?php
/*KETIKA TOMBOL SEND DITEKAN*/
  if (isset($_POST['send_book'])) {
               if ($_GET['hal'] == "update" ) {	
                   $update = mysqli_query($koneksi, "UPDATE `tbl_kategori` SET  
          			DIINPUT_OLEH='$_POST[DIINPUT_OLEH]',
          			NAMA_KATEGORI='$_POST[NAMA_KATEGORI]',
                         DESKRIPSI_OPSIONAL='$_POST[DESKRIPSI_OPSIONAL]'

                         WHERE ID_KATEGORI='$_GET[id]'
                         
                         ");
            if ($update) {
                  echo "<script>
                      alert ('Kategori Telah Behasil Di update');
                      document.location='?page=kategori';
                        </script>";
            }
                  

              }
          elseif ($_GET['hal'] == "create" ) {
            
/*CEK DATA KE DATABASE*/
	    	$NAMA_KATEGORI = $_POST['NAMA_KATEGORI'];
        $AUTH_ISBN = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tbl_kategori WHERE NAMA_KATEGORI='$NAMA_KATEGORI'"));
    if ($AUTH_ISBN > 0) {
                    $auth = true;
                   
/*END CEK DATA*/
    } else {
	
				$insert = mysqli_query($koneksi, "INSERT INTO `tbl_kategori` VALUES (
               '',
               '$_POST[KODE_KATEGORI]',
               '$_POST[TANGGAL_INPUT]',
               '$_POST[DIINPUT_OLEH]',
               '$_POST[NAMA_KATEGORI]',
               '$_POST[DESKRIPSI_OPSIONAL]'
              
               )");
               if ($insert) {
                echo "<script>
                      alert ('kategori has been created');
                      document.location='?page=kategori';
                      </script>";
                }
              }
            }
        }
/*END TOMBOL SEND*/
   


/*KODE OTOMATIS*/
     $sql = "SELECT max(ID_KATEGORI) as max_id FROM tbl_kategori WHERE ID_KATEGORI ORDER BY ID_KATEGORI DESC LIMIT 1";
     $query1 = mysqli_query($koneksi, $sql);
     $E_PERPUS = mysqli_fetch_assoc($query1);
     $getid = $E_PERPUS['max_id'];
     $no = substr($getid, -5, 5);
     $no = (int) $no;
     $no = $no + 1;
     $nid = sprintf("%05s", $no);
/*END KODE OTOMATIS*/
     
/*MENAMPILKAN DATA YANG AKAN DI-UPDATE*/
      $tampil = mysqli_query($koneksi, "SELECT * from `tbl_kategori` WHERE ID_KATEGORI='$_GET[id]'");
        $E_PERPUS = mysqli_fetch_array($tampil);
             if ($E_PERPUS) {
                   $vnama_kategori     = $E_PERPUS['NAMA_KATEGORI'];
                   $vdesop             = $E_PERPUS['DESKRIPSI_OPSIONAL'];
                   $v   = $E_PERPUS['PENGARANG'];
                   $v  = $E_PERPUS['PENERBIT'];
                   $v    = $E_PERPUS['PENELAAH'];
               }
           
?>
 
 <div class="right_col" role="main">
   <div class="">
     <div class="page-title">
       <div class="title_left">
         <h3> </h3>
       </div>

       <div class="title_right">
        <div class="col-md-5 col-sm-5 form-group pull-right top_search">
          <div class="input-group">
              <input type="text" class="form-control" placeholder="Search for...">
              <span class="input-group-btn">
               <button class="btn btn-default" type="button">Go!</button>
              </span>
           </div>
         </div>
       </div>
     </div>

     <div class="clearfix"></div>

     <div class="row">
              <div class="col-md-12 col-sm-12 ">
         <div class="x_panel">
           <div class="x_title">
             <h2><span class="fa fa-edit"></span> Form Input Kategori Baru</h2>
         <ul class="nav navbar-right panel_toolbox">

         </ul>
      <div class="clearfix"></div>
   </div>
 <div class="x_content"><br>
 
 <div class="row">
                <?php
  if (isset($auth)) : ?>
             &ensp;&ensp;&ensp;<div class="alert alert-warning col-md-5 col-md-5 col-sm-5 form-group pull-right"
             >
                <a data-dismiss="alert" style="float: right">
                   <i class="fa fa-close"></i>
                </a>
                  <strong>Warning !!</strong> Username Or Password Not Found
              </div>
              
  <?php endif; ?>
  </div>
<form action="" method="POST" enctype="multipart/form-data" class="form-horizontal form-label-left">
<div class="item form-group">
  	<label class="control-label col-md-3  " for="KODE_KATEGORI"> KODE KATEGORI <span class="required" >*</span>
  	</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="KODE_KATEGORI" name="KODE_KATEGORI" class="form-control "placeholder="" value="E-PERPUS/KAT/<?=date("yy.").$nid;?>" readonly>

</div>
</div>
<div class="item form-group">
		<label class="control-label col-md-3" for="TANGGAL_INPUT"> TANGGAL INPUT <span class="required">*</span> 
		</label> 
<div class="col-md-7 col-sm-7">
		 <input type="text" id="TANGGAL_INPUT" name="TANGGAL_INPUT" required="required" class="form-control"  value="<?=date("l, d-m-y h:i:s");?>" readonly>
</div>
</div>

<div class="item form-group">
		<label class="control-label col-md-3" for="DIINPUT_OLEH"> DIINPUT OLEH <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="DIINPUT_OLEH" name="DIINPUT_OLEH" required="required" class="form-control"value="<?=$_SESSION['username']?>" readonly="">
		
</div>
</div>

<div class="item form-group">
		<label class="control-label col-md-3" for="NAMA_KATEGORI"> NAMA KATEGORI <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<input type="text" id="NAMA_KATEGORI" name="NAMA_KATEGORI" required="required" class="form-control"value="<?=$vnama_kategori?>" >
		
</div>
</div>

<div class="item form-group">
		<label class="control-label col-md-3" for="DESKRIPSI_OPSIONAL"> DESKRIPSI OPSIONAL <span class="required">*</span>
		</label>
<div class="col-md-7 col-sm-7">
		<textarea id="DESKRIPSI_OPSIONAL" rows="8" name="DESKRIPSI_OPSIONAL" required="required" class="form-control" onclick="document.getElementById('cdesof').innerHTML='Contoh :  Buku seri cerita Fiksi'" autocomplete="off"><?=$vdesop?>
		</textarea>
		<small id="cdesof"></small>
</div>
</div>

										
<br>
<div class="item form-group ">
     <div class="container text-center">
       <input type="checkbox" class="my-2" id="sdk" required>
     <label class="" for="sdk"> I Have read and agree <a href=""><a href="" data-toggle="modal" data-target="#SDK"><strong>Terms and condition</strong></a> in Elektronik Perpustakaan application</label>
</div>
</div>
										
<div class="ln_solid"></div>
     <div class="item form-group">
          <div class="col-md-7 col-sm-7 offset-md-3">
		     <a href="?page=kategori" class="btn btn-dark" type="button"><i class="fa fa-arrow-circle-o-left"> </i> BACK </a>
		     <a href="" class="btn btn-secondary" type="reset">RESET</a>
		     <button type="submit" name="send_book" class="btn btn-success">SEND</button>
		</div>
	</div>
</form>

  </div>
    </div>
      </div>
      

              </div>
            </div>
  
      
        </div>
          </div>
            </div>
       
<!-- /page content -->

<!-- Modal Popup -->
     
<div class="modal fade" id="SDK" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New Book</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

<p>
    Dengan Mengklik yes anda berarti menerima dan menyetujui syarat dan ketentuan aplikasi elektronik Perpustakaan
</p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>

<!-- end Modal Popup -->
