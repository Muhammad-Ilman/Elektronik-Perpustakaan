<?php
     session_start();
     unset($_SESSION['username']);
     session_destroy();
     ob_clean();
    header('location: ../../LOGIN');
?>