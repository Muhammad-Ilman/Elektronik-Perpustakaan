<?php
include("CONFIG/koneksi.php");
function register($data) {
  global $koneksi;
            $username      = strtolower(stripslashes($data['RUSERNAME']));
            $password      = mysqli_real_escape_string($koneksi, $data['RPASSWORD']);
            $password2     = mysqli_real_escape_string($koneksi, $data['CPASSWORD']);
            $cekuser       = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM tbl_admin WHERE username='$data[RUSERNAME]'"));
     function cekuser($data){
              global $koneksi;
         }
           
                 if ($cekuser > 0) {
                        $calready = "<center>
                                        <div class='alert alert-info' style='margin-right: 25px; margin-left: 25px;'>
                                           <a data-dismiss='alert' style='float: right'>
                                            <i class='fa fa-close'></i>
                                           </a>
                                          <strong>Note !</strong> Account Already Exist
                                       </div>
                                     <center><br>";
                            echo "$calready";
                          return false;
                     } 
                
                 if ($password !== $password2) {
                     $cpass = "<center><div class='alert alert-info' style='   margin-right: 20px;
                           margin-left: 20px;'>
                     <a data-dismiss='alert' style='float: right'>
                        <i class='fa fa-close'></i>
                     </a>
                       <strong>Note !</strong> please confirm your password
                   </div><center>";
                            	echo "$cpass";
                          return false;
                 }
                 
  
                
            
              if (!empty($_FILES["GAMBAR"]["tmp_name"])) {
            	$JENIS=$_FILES['GAMBAR']['type'];
               	 if($JENIS=="image/jpeg"|| 
              	    $JENIS=="image/jpg" || 
               	    $JENIS=="image/gif" ||
               	    $JENIS=="image/png") {
              	     $E_FOLDER="CONTROLLER/ADMIN_SYSTEM/G_ADMIN/"; //tempat save file
                      $G_GAMBAR = $E_FOLDER . basename($_FILES['GAMBAR']['name']);		
                      $GAMBAR = $_FILES['GAMBAR']['name'];		
	   
	         	if (move_uploaded_file($_FILES['GAMBAR']['tmp_name'], $G_GAMBAR)) {
		  
   
	
            $firsname = $data['FIRST_NAME'];
            $lastname = $data['LAST_NAME'];
            $email    = $data['EMAIL'];
            $telepon  = $data['TELEPON'];
            $level    = $data['LEVEL'];
            $status   = $data['STATUS'];
              
      

              

            $password = password_hash($password, PASSWORD_DEFAULT);
            $tanggal = date("l, d-m-y h:i:s");
				$reg = mysqli_query($koneksi, "
				    INSERT INTO tbl_admin VALUES(
				    '',
				    '$firsname',
				    '$lastname',
				    '$username',
				    '$password',
				    '$telepon',
				    '$email',
				    '$GAMBAR',
				    '$level',
				    '$tanggal',
				    '$status'
				    )
				"
               );
                   
                return mysqli_affected_rows($koneksi);
	         	} else {
	         /*       echo "<script>
                      alert ('Akun gagal dibuat');
                      document.location='Home?halaman=buku&hal=create';
                        </script>";*/
                }
                } else {
              		echo "<script>
                      alert ('Gambar anda tidak memenuhi spesifikasi Harap masukkan jenis file .jpeg .jpg .gif');
                      document.location='Home?halaman=buku&hal=create';
                        </script>";

                }
            } 
                
               
}

function login($data) {
  global $koneksi;
     $username = mysqli_real_escape_string($koneksi, $_POST['USERNAME']);
     $password = mysqli_real_escape_string($koneksi, $_POST['PASSWORD']);
     $login = mysqli_query($koneksi, "SELECT * FROM tbl_admin WHERE USERNAME='$username'");
 if(mysqli_num_rows($login) === 1){
   $data = mysqli_fetch_assoc($login);
   if (password_verify($password, $data['PASSWORD'] ) ) {
          
          if ($data['LEVEL'] == "ADMINISTRATOR" ||"OPERATOR" || "EDITOR") {
                  // SESSION ADMINISTRATOR / MASTER
              $_SESSION["username"] = $username;
              $_SESSION["gambar"] = $data['GAMBAR'];
              $_SESSION["LEVEL"] = $data['LEVEL'];
                  header('location: Home');
                      exit;
      }
      
   }
}
}
?>