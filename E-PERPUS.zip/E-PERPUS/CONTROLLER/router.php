<!-- Elektronik Perpustakaan Content -->
  
<?php
ob_start();
session_start();
    if (!isset($_SESSION['username'])) {
      header('location: LOGIN');
      
    } else {
      
          require_once("CONFIG/koneksi.php");
          require_once("ASSETS/TEMPLATE/header.php");

               if(@$page = $_GET['page']) {
                 if ($page == "buku") {
                         if (@$_GET['hal'] == "create" ||
                             @$_GET['hal'] == "update" ) {
                              include("MODUL/DATA BUKU/buku_baru.php");
                       }
                     elseif (
                          @$_GET['hal'] == "delete" ||
                          @$_GET['hal'] == "read"
                     ) {
                              include("MODUL/DATA BUKU/data_buku.php");
                       }
                     elseif (@$_GET['hal'] == "detail" ) {
                              include("MODUL/DATA BUKU/detail.php");
                     } else {
                         include("MODUL/DATA BUKU/data_buku.php");
                     }
                 }
                 
                if ($page == "kategori") {
                         if (@$_GET['hal'] == "create" || 
                             @$_GET['hal'] == "update"  ) {
                              include("MODUL/DATA KATEGORI/kategori_baru.php");
                         }
                     elseif (@$_GET['hal'] == "delete" ) {
                              include("MODUL/DATA KATEGORI/data_kategori.php");
                         }
                         
                         else {
                              include("MODUL/DATA KATEGORI/data_kategori.php");
                         }
                }
                 
                 
                 
                 
                 
             elseif ($page == "lainnya") {
                         if (@$_GET['hal'] == "disclaimer" ) {
                              include("MODUL/LAINNYA/disclaimer.php");
                         }
                     elseif (@$_GET['hal']) {
                         // code...
                       }
             }
           
             elseif ($page == "error") {
                   include("MODUL/ERROR/403.html");
             }  
               
               
     
 
               }
   
            else {
                 include("MODUL/Dashboard.php");
          }
     
          require_once("ASSETS/TEMPLATE/footer.php");

    }
?>