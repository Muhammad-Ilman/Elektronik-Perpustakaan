<?php
session_start();
if(!empty($_SESSION['username'])){
     header('location : HOME');
} else {

require("CONFIG/koneksi.php");
require("CONTROLLER/ADMIN_SYSTEM/function.php");

if (isset($_POST['register'])) {
    if ( register($_POST)) {
        $success = true;
    } else {
        
        $alredy  = true;
       
    }

}


if (isset($_POST['LOGIN'])) {
     if (login($_POST)) {
 }
   
 $error = true;
   
}


    


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
  

    <title>CPANEL ELEKTRONIK PERPUSTAKAAN </title>

    <!-- Bootstrap -->
    <link href="ASSETS/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="ASSETS/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="ASSETS/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="ASSETS/vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="ASSETS/VENDORS/build/css/custom.min.css" rel="stylesheet">
    <style>
        .input {
            border-radius:10px
        }
        .input:hover {
            transform: scale(1.1);
            transition: 1s;
        }
    </style>
  </head>
 
  <body class="login" style="margin-top: 280px;
  height:100%; text-decoration:none">
    
        
    
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>
    
      <div class="login_wrapper">
        <div class="animate form login_form">
           <center>
                <?php
  if (isset($error)) : ?>
             <div class="alert alert-warning">
                <a data-dismiss="alert" style="float: right">
                   <i class="fa fa-close"></i>
                </a>
                  <strong>Warning !!</strong> Username Or Password Not Found
              </div>
  <?php endif; ?>
  <br>
  <br>
               <img src="ASSETS/FILE/LOGO_E-PERPUS.png" width="180" height="145">
               <br>
               <br>
               <br>
            <form action="" method="post" class="form-label-left input_mask" enctype="multipart/form-data">
              <h4><i class="fa fa-graduation-cap"></i> Login Cpanel
              </h4>
             
                <br>
                
             	<div class="col-md-12 col-sm-12 form-group has-feedback">
			    	<input type="text" name="USERNAME" class="form-control has-feedback-left input" placeholder="Username" autocomplete="off" required="">
			        <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
               	</div>
             	<div class="col-md-12 col-sm-12 form-group has-feedback">
			    	<input type="password" name="PASSWORD" class="form-control has-feedback-left input" placeholder="Password" required="">
			        <span class="fa fa-lock form-control-feedback left" aria-hidden="true"></span>
			        <br>
               	</div>
               	<br>

              <div>
                <button class="btn btn-sm btn-secondary">Back</button>
                <button type="submit" class="btn btn-sm btn-success" name="LOGIN" >Login</button>
             
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">Dont have account?
                  <a href="#signup" class="to_register"> Create Account </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <h5><i class="fa fa-university"></i> SMP Negeri 3 Cibeber</h5>
                  <p>&copy; <?=date('yy')?> All Rights Reserved. Elektronik Perpustakaan
                  <a href="" data-toggle="modal" data-target="#SDK">Muhammad Ilman</a>
                  </p>
                </div>
              </div>
            </form>
          </center>
        </div>

        <div id="register" class="animate form registration_form">
 <center>
                     <?php
  if (isset($success)) : ?>
             <div class="alert alert-success">
                <a data-dismiss="alert" style="float: right">
                   <i class="fa fa-close"></i>
                </a>
                  <strong>Note !</strong> Account Has Been Created 
              </div>
  <?php endif; ?>                     
  <?php
  if (isset($alredy)) : ?>
             <div class="alert alert-info">
                <a data-dismiss="alert" style="float: right">
                   <i class="fa fa-close"></i>
                </a>
                  <strong>Note !</strong> Account Already Exists or Your Password Confirmation Does Not Match
              </div>
  <?php endif; ?>
  

  
  <br>
               <img src="ASSETS/FILE/LOGO_E-PERPUS.png" width="180" height="145">
               <br>
               <br>
               <br>
           
            <form action="" method="post" class="form-label-left input_mask" enctype="multipart/form-data">
              <h4> Create Account
              </h4>
             
                <br>
                	<div class="col-md-6 col-sm-6  form-group has-feedback">
		            	<input type="text" name="FIRST_NAME" class="form-control has-feedback-left input" id="inputSuccess2" placeholder="First Name" autocomplete="off" required="">
							    <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
										</div>
										
                	<div class="col-md-6 col-sm-6  form-group has-feedback">
		            	<input type="text" name="LAST_NAME" class="form-control has-feedback-left input" id="inputSuccess2" placeholder="Last Name" autocomplete="off" required="">
								<span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
										</div>


		        	<div class="col-md-6 col-sm-6  form-group has-feedback">
						<input type="email" name="EMAIL" class="form-control has-feedback-left input" id="inputSuccess4" placeholder="Email" autocomplete="off" required="">
						    	<span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
					</div>
										
			    	<div class="col-md-6 col-sm-6  form-group has-feedback">
							<input type="tel" name="TELEPON" class="form-control has-feedback-left input" id="inputSuccess4" placeholder="Telphone" autocomplete="off" required="">
						    	<span class="fa fa-phone form-control-feedback left" aria-hidden="true"></span>
					</div>
			        <div class="col-md-12 col-sm-12 form-group has-feedback">
			        	<input type="text" name="RUSERNAME" class="form-control has-feedback-left input" placeholder="Username" autocomplete="off" required="">
			            <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                   	</div>
			        <div class="col-md-12 col-sm-12 form-group has-feedback">
			        	<input type="password" name="RPASSWORD" class="form-control has-feedback-left input" placeholder="Password" autocomplete="off" required="">
			            <span class="fa fa-lock form-control-feedback left" aria-hidden="true"></span>
                   	</div>
			        <div class="col-md-12 col-sm-12 form-group has-feedback">
			        	<input type="password" name="CPASSWORD" class="form-control has-feedback-left input" placeholder="Confirm Password" autocomplete="off" required="">
			            <span class="fa fa-check-circle-o form-control-feedback left" aria-hidden="true"></span>
                   	</div>
			        <div class="col-md-12 col-sm-12 form-group has-feedback">
			        	<input type="file" name="GAMBAR" class="form-control has-feedback-left input" autocomplete="off" required="">
			            <span class="fa fa-image form-control-feedback left" aria-hidden="true"></span>
                   	</div>
                   	
				    <div class="btn-group col-md-6 col-sm-6 form-group has-feedback">
                    <select name="LEVEL" class="form-control input">
                      
                   
                      <option class="dropdown-item" href="#">Level Account</option>
                      <option class="dropdown-item" href="#">ADMINISTRATOR</option>
                      <option class="dropdown-item" href="#">OPERATOR</option>
                      <option class="dropdown-item" href="#">EDITOR</option>

                  
                    </select>
                  </div>
                  <div class="btn-group col-md-6 col-sm-6 form-group has-feedback">
                    <select name="STATUS" id="STATUS" class="form-control input">
                    
                   
                      <option class="dropdown-item" value="">Status Account</option>
                      <option class="dropdown-item" value="AKTIF">AKTIF</option>
                      <option class="dropdown-item" value="NONAKTIF">NONAKTIF</option>
                  
                    </select>
                  </div>
              <div>

                <button class="btn btn-sm btn-secondary my-3" >Cancel</button>
                <button type="submit" name="register" class="btn btn-sm btn-success my-3" >Create Account</button>
             
              </div>

              <div class="clearfix"></div>


              <div class="separator">
                <p class="change_link">Already a member ?
                  <a href="#signin" class="to_register"> Log in </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <h5><i class="fa fa-university"></i> SMP Negeri 3 Cibeber</h5>
                  <p>&copy; <?=date('yy')?> All Rights Reserved. Elektronik Perpustakaan
                  <a href="" data-toggle="modal" data-target="#SDK">Muhammad Ilman</a>
                  </p>
                </div>
              </div>
            </form>
          </center>
        </div>
      </div>
    
    <!-- Modal Popup -->
     
<div class="modal fade" id="SDK" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-user"></i> Developer Profil</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

<pre class="input">
    <img src="ASSETS/FILE/SMPN3CIBEBER.png" width="50" height="50">
    Nama Lengkap : M.Ilman Pratama Supardi Putra
    Email        : PratamaIlman06@gmail.com
    Git-hub      : Muhammad_ilman
    Projects     : Elektronik Perpustakaan
</pre>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>

<!-- end Modal Popup -->

  <!-- jQuery -->
  <script src="ASSETS/vendors/jquery/dist/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="ASSETS/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- FastClick -->
  <script src="ASSETS/vendors/fastclick/lib/fastclick.js"></script>

  <!-- Custom Theme Scripts -->
  <script src="ASSETS/build/js/custom.min.js"></script>
  <!-- Bootstrap -->
  <script src="ASSETS/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
  </body>
</html>
<?php } ?>