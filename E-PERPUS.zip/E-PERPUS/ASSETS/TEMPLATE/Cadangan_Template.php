

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="ASSETS/images/icon.ico" type="image/ico" />

    <title>Elektronik Perpustakaan</title>

    <!-- Bootstrap -->
    <link href="ASSETS/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="ASSETS/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="ASSETS/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="ASSETS/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
	
    <!-- bootstrap-progressbar -->
    <link href="ASSETS/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="ASSETS/vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="ASSETS/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.php" class="site_title"><i class="fa fa-book"></i> <span>E-PERPUS</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="images/img.jpg" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome <?$username['username']?></span>
                <h2>John Doe</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>ADMINISTRATOR PANEL</h3>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-dashboard"></i> Dashboard <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="index.php">Dashboard<span class="fa fa-home"></span></a>
                      </li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-book"></i> Data Buku<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="#">Buku Baru<span class="fa fa-edit"></span></a></li>
                      <li><a href="#">Data Buku<span class="fa fa-book"></span></a>
                      </li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-group"></i> Data Peminjam <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="#">Peminjam Baru <span class="fa fa-edit"></span></a></li>
                      <li><a href="#">Data Peminjam</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-refresh fa-spin fa-1x"></i> Simpan Pinjam <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="#">Pinjaman Baru<span class="fa fa-edit"></span></a></li>
                      <li><a href="#">Data Peminjaman<span class="fa fa-sign-out"></span></a></li>
                      <li><a href="#">Data Pengembalian<span class="fa fa-sign-in"></span></a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-sitemap"></i> Data Admin <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="#">Master Admin</a></li>
                      <li><a href="#">Operator</a></li>
                      <li><a href="#">Editor</a></li>
                    </ul>
                  </li>
                  <li><a><i class="fa fa-database"></i>BACKUP <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="#">Database Buku<span class="fa fa-database"></span></a></li>
                      <li><a href="#">Database Peminjam<span class="fa fa-database"></span></a></li>
                      <li><a href="#">Database User<span class="fa fa-database"></span></a></li>
                    </ul>
                  </li>
                </ul>
              </div>
              <div class="menu_section">
                <h3>Lainnya</h3>
                <ul class="nav side-menu">

                  <li><a><i class="fa fa-cog"></i>
                  <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                        <li>
                        <li><a> Lainnya <span class="fa fa-chevron-circle-down"></span></a>
                          <ul class="nav child_menu">
                            <li class="sub_menu">
                            <a href="#"><span class="fa fa-info-circle"></span>Tentang E-PERPUS</a>
                            </li>
                            <li><a href="#"><span class="fa fa-check-square-o"></span>Terms and Condition</a>
                            </li>
                            <li><a href="#"><span class="fa fa-lock"></span>Privacy Policy</a>
                            </li>
                            </li>
                            <li><a href="#"><span class="fa fa-exclamation-triangle"></span>Disclaimer</a>
                            </li>
                            </li>
                            <li><a href="#"><span class="fa fa-user"></span>About Depeloper</a>
                            </li>
                          </ul>
                        </li>
                    </ul>
                  </li>                  
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.html">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="glyphicon glyphicon-th"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <img src="images/img.jpg" alt="">Administrator
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                       <a class="dropdown-item"> My Profile 
                         <span class="fa fa-user pull-right"></span>
                         </a>
                      <a class="dropdown-item" href="#">
                        <span>Settings</span>
                        <span class="fa fa-cog pull-right"></span>
                      </a>
                  <a class="dropdown-item" href="#">Help                 
                  <span class="fa fa-question-circle pull-right"></span>
                  </a>
                   <a class="dropdown-item"  href="#"><i class="fa fa-sign-out pull-right"></i> Log Out
                   </a>
                  </div>
                </li>

                <li role="presentation" class="nav-item dropdown open">
                  <a href="javascript:;" class="dropdown-toggle info-number" id="navbarDropdown1" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-bell"></i>
                    <span class="badge bg-green">6</span>
                  </a>
                  <ul class="dropdown-menu list-unstyled msg_list" role="menu" aria-labelledby="navbarDropdown1">
                    <li class="nav-item">
                      <a class="dropdown-item">
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="dropdown-item">
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="dropdown-item">
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="dropdown-item">
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li class="nav-item">
                      <div class="text-center">
                        <a class="dropdown-item">
                          <strong>See All Alerts</strong>
                          <i class="fa fa-angle-right"></i>
                        </a>
                      </div>
                    </li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
        <!-- content 1 -->
                    <!-- page content -->
        
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <!--<h3>E-PERPUS</h3>-->
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Notifications</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      
                  </div>
                </div>
              </div>
            </div>
          </div>
        
        <!-- /page content -->

        <!--/ content 1 end -->
          <div class="row">
            <div class="col-md-12 col-sm-12 ">
              <div class="dashboard_graph">

                <div class="row x_title">
                  <div class="col-md-6">
                    <h5>GRAFIK PENGUNJUNG PERPUSTAKAAN</h5>
                  </div>
                  <div class="col-md-6">
                    <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
                      <i class="fa fa-calendar"></i>
                      <span>DD-MM-YYYY</span> <b class="caret"></b>
                    </div>
                  </div>
                </div>

                <div class="col-md col-sm ">
                  <div id="chart_plot_01" class="demo-placeholder"></div>
                   <img class="col-md col-sm" src="Welcome.jpg">
                  
                </div>

                
                
              </div>
            </div>

          </div>
          <br />

          <div class="row">

          </div>


          <div class="row">
           
          </div>
          
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
               <span class="fa fa-book"></span>
             <a href="#"> E-PERPUS </a><span class="fa fa-copyright"></span> <?=date('yy')?> | Pratama Ilman
          </div>
          <span class="fa fa-github"></span>
          <span class="fa fa-twitter-square"></span>
          <span class="fa fa-facebook-square"></span>
          <span class="fa fa-dropbox"></span>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="ASSETS/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="ASSETS/vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="ASSETS/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="ASSETS/vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="ASSETS/vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="ASSETS/vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="ASSETS/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="ASSETS/vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="ASSETS/vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="ASSETS/vendors/Flot/jquery.flot.js"></script>
    <script src="ASSETS/vendors/Flot/jquery.flot.pie.js"></script>
    <script src="ASSETS/vendors/Flot/jquery.flot.time.js"></script>
    <script src="ASSETS/vendors/Flot/jquery.flot.stack.js"></script>
    <script src="ASSETS/vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="ASSETS/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="ASSETS/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="ASSETS/vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="ASSETS/vendors/DateJS/build/date.js"></script>
    <!-- JQVMap -->
    <script src="ASSETS/vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="ASSETS/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="ASSETS/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="ASSETS/vendors/moment/min/moment.min.js"></script>
    <script src="ASSETS/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
	
  </body>
</html>
