<!-- Elektronik Perpustakaan -->
<?php
  
         // Mengambil CONTROLLER
    require_once("CONTROLLER/router.php");
    
?>
<!-- E - PERPUS -->