<!DOCTYPE html>
<html>
<head>
 <title>PRINT DETAIL <?php echo("$JUDUL_BUKU")?> BUKU - ELEKTRONIK PERPUSTAKAAN </title>
</head>

<link rel="stylesheet" href="Bootstrap-5/css/Bootstrap.min.css">
    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="vendors/build/css/custom.min.css" rel="stylesheet">
<body style="background-color: white">
<div class="container">
 <img src="FILE/LOGO_E-PERPUS.png"class="ml-5" style="float: left;border-radius:10px" width="100px" height="80px">
 <img src="FILE/SMPN3CIBEBER.png" class="mr-5 mt-4" style="float: right"  width="55px" height="50px">&ensp;
<center> <h6 class="">ELEKTRONIK PERPUSTAKAAN - E-PERPUS </br><small>SMP NEGERI 3 CIBEBER</small><br><small class="" style="font-size:8px">Jalan Cipadang Lampegan Km.12 Desa Cibokor, Kec. Cibeber, kab. Cianjur 43262</small></h6>

</center>

 <hr class="mt-4" style="border-color:black;border-radius:6px">
 <br>
 <br>

 
  <?php 
  date_default_timezone_set('Asia/Jakarta');
  // koneksi database
  require("CONFIG/koneksi.php");

  // menampilkan data detail buku
  $query="select * from tbl_buku WHERE ID_BUKU='$_GET[printid]'";
    $tampil = mysqli_query($koneksi, $query);
    $E_PERPUS   = mysqli_fetch_array($tampil);
        
        $ID_BUKU         = $E_PERPUS['ID_BUKU'];
        $KODE_BUKU       = $E_PERPUS['KODE_BUKU'];
        $JUDUL_BUKU      = $E_PERPUS['JUDUL_BUKU'];
        $ISBN            = $E_PERPUS['ISBN'];
        $PENULIS         = $E_PERPUS['PENGARANG'];
        $PENERBIT        = $E_PERPUS['PENERBIT'];
        $PENELAAH        = $E_PERPUS['PENELAAH'];
        $TAHUN_TERBIT    = $E_PERPUS['TAHUN_TERBIT'];
        $EDISI           = $E_PERPUS['EDISI'];
        $KATEGORI        = $E_PERPUS['KATEGORI'];
        $TANGGAL_INPUT   = $E_PERPUS['TANGGAL_INPUT'];
        $CARA_PENGADAAN  = $E_PERPUS['CARA_PENGADAAN'];
        $HARGA           = $E_PERPUS['HARGA'];
        $LOKASI          = $E_PERPUS['LOKASI'];
        $JUMLAH_BUKU     = $E_PERPUS['JUMLAH_BUKU'];
        $BARCODE         = $E_PERPUS['BARCODE'];
        $DESFIS          = $E_PERPUS['DESKRIPSI_FISIK'];
        $DESOPS          = $E_PERPUS['DESKRIPSI_OPSIONAL'];
        $TAGS_BOOK       = $E_PERPUS['TAGS_BOOK'];
  ?>                
  <div class="">
  <table id="example" class="table table-hover table-bordered ">
                    <tr>
                    <td>ID BUKU</td>
                    <td><?=$ID_BUKU?></td>
                    <td rowspan="6"><center>ISBN BARCODE - QR
                       <img src="<?=$BARCODE?>" height="210" width="270" alt="<?=$ISBN?>"/><br>
                            <?=$ISBN?>
                        </center></td>
                    </tr>

                    <tr>
                    <td width="200">KODE BUKU</td>
                    <td width="500"><?=$KODE_BUKU?></td>
                    </tr>
                    <tr>
                    <td>ISBN NO</td>
                    <td><?=$ISBN?></td>
                    </tr>
                    
                    <tr>
                    <td>TANGGAL INPUT</td>
                    <td><?=$TANGGAL_INPUT?></td>
                    </tr>
                    
                    <tr>
                    <td>JUDUL BUKU</td>
                    <td><?=$JUDUL_BUKU?></td>
                    </tr>
                    
                    <tr>
                    <td>PENULIS</td>
                    <td><?=$PENULIS?></td>
                    </tr>
                    
                    <tr>
                    <td>PENERBIT</td>
                    <td colspan="2"><?=$PENERBIT?></td>
                    </tr>
                    
                    <tr>
                    <td>PENELAAH</td>
                    <td colspan="2"><?=$PENELAAH?></td>
                    </tr>
                    
                    <tr>
                    <td>EDISI</td>
                    <td colspan="2"><?=$EDISI?></td>
                    </tr>
                    
                    <tr>
                    <td>TAHUN TERBIT</td>
                    <td colspan="2"><?=$TAHUN_TERBIT?></td>
                    </tr>
                    
                    
                    <tr>
                    <td>JUMLAH BUKU</td>
                    <td colspan="2"><?=$JUMLAH_BUKU ?></td>
                    </tr>
                    
                    
                    <tr>
                    <td>LOKASI</td>
                    <td colspan="2"><?=$LOKASI?></td>
                    </tr>
                    
                    <tr>
                    <td>HARGA</td>
                    <td colspan="2"><?=$HARGA?></td>
                    </tr>
                    
                    <tr>
                    <td>CARA PENGADAAN</td>
                    <td colspan="2"><?=$CARA_PENGADAAN?></td>
                    </tr>
                    
                    <tr>
                    <td>KATEGORI</td>
                    <td colspan="2"><?=$KATEGORI?></td>
                    </tr>
                    
                    <tr>
                    <td>DESKRIPSI FISIK</td>
                    <td colspan="2"><?=$DESFIS?></td>
                    </tr>
                    
                    <tr>
                    <td>DESKRIPSI OPSIONAL</td>
                    <td colspan="2"><?=$DESOPS?></td>
                    </tr
                    
                    <tr>
                    <td>TAGS BOOK</td>
                    <td colspan="2"><?=$TAGS_BOOK?></td>
                    </tr>
                    
                    

                   </table>
                   </div>
      <div class="ln_solid"></div>             

<p>Dicetak Oleh : <?=$PENULIS?></p>
<p>Pada Tanggal : <?=date("l, d-M-y h:i")?> wib</p>

 </div>
 <script type="text/javascript" src="BOOTSTRAP-5/JS/Bootstrap.min.js"></script>
     <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="vendors/nprogress/nprogress.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
    <script type="text/javascript">
      window.print();
    </script>
</body>
</html>