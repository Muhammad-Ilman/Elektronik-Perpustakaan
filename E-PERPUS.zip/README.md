## ELEKTRONIK PERPUSTAKAAN
### Powered By : Muhammad Ilman
Terima Kasih Telah Menggunakan Layanan Elektronik Perpustakaan, aplikasi perpustakaan elektronik ini adalah aplikasi kedua yang saya selesaikan pada Oktober 2020 untuk memulai aplikasi ini silahkan ikuti cara penginstalan dibawah ini :

1. Silahkan Exstrak File Zip atau Rar menggunakan WinRAR atau sejenisnya.
2. Pindahkan Ke Htdocs Dimana anda menginstal XAMPP/LAMPP atau untuk pengguna android dapat menggunakan KSWEB Server.
3. Login ke Mysql Client / phpMyAdmin anda dan silahkan Buat Database PERPUSTAKAAN dengan nama PERPUSTAKAAN. 
4. Lalu Import Table dengan jenis file SQL yang dapat anda dapatkan di direktori (E-PERPUS/ASSETS/DATABASE/perpustakaan.sql).
5. Silahkan Buka Dibrowser "localhost/E-PERPUS" atau "localhost:port/E-PERPUS".
6. Silahkan Login dengan Master Administrator Atau Anda dapat Melakukan Registrasi Admin Terlebih dahulu.
7. Akun Master :
     ### USERNAME : SMP NEGERI 3 CIBEBER
     ### PASSWORD : SMP NEGERI 3 CIBEBER (sertakan karakter spasi)